# VMware Offline IoT Second-Laptop Test (openSUSE Leap 15.6)

**Test purpose:** Treat the **currently working VMware openSUSE VM** as a second laptop, and validate EMQX 5.8.9, Kafka 3.9.2, the Node.js User Management UI and the already-running ThingsBoard CE 4.3.1.8/ PostgreSQL **without network downloads or changing the original installation**.

This lab creates a **new directory** (default `/root/iot-vmware-laptop2-test` when run as root, or `$HOME/iot-vmware-laptop2-test` for a normal user). It copies the needed binaries there, maintains its own Kafka KRaft metadata, its own EMQX node identity/data, and its own Node.js user store. It **does not copy PostgreSQL data, change its credentials, initialize ThingsBoard again, or rerun Maven/Yarn builds**.

> **Scope:** This is an **isolated runtime/integration test on the same operating system**, not proof that an empty second laptop has all offline RPM dependencies installed. The ThingsBoard and PostgreSQL checks intentionally use the already-running local services on `8080` and `5432`. A fresh-OS test is a later step after this lab passes.

## 1. Copy this folder to your VMware environment

The downloadable ZIP/TAR.GZ contains this README, `lab.sh`, and the standalone **User Management Node.js project** (no `npm install` required). The EMQX/Kafka distributions are **not bundled**: the script stages them from `/opt/iot-offline-opensuse15.6/repos` or your downloaded release archives.

```bash
# In VMware, after copying the ZIP into your Downloads directory:
mkdir -p ~/iot-test-installer
cd ~/iot-test-installer
unzip /path/to/vmware-offline-laptop-test.zip
cd vmware-offline-laptop-test
chmod +x lab.sh
```

If the original complete offline repository is at another path, set `ROOT=/path/to/iot-offline-opensuse15.6` before the commands below.

> **No network:** Disconnect the VMware virtual NIC in VMware settings before testing to mimic the offline laptop. Keep loopback networking (`127.0.0.1`) enabled. The scripts do not invoke `curl` to external hosts, `zypper`, `docker pull`, `git clone`, or `npm install`.

## 2. Isolated port map

| Component | Lab address | Original installation remains unchanged |
|---|---|---|
| EMQX MQTT | `127.0.0.1:1884` | Leaves 1883 available |
| EMQX Dashboard | `http://127.0.0.1:18084` | Leaves 18083 available |
| EMQX internal Erlang node | `emqx77@127.0.0.1` | Distinct from `emqx@...`; numeric node suffix shifts internal Erlang ports |
| Kafka broker | `127.0.0.1:9094` | Leaves 9092 available |
| Kafka KRaft controller | `127.0.0.1:9095` | Leaves 9093 available |
| Node.js User Management | `http://127.0.0.1:3001` | Leaves 3000 available |
| ThingsBoard CE **existing service** | `http://127.0.0.1:8080` | Read-only health check |
| PostgreSQL **existing service** | `127.0.0.1:5432` | Readiness check only |

All test listeners are loopback-only. This is a **development test**, not a production security configuration.

## 3. Prepare new folder (non-destructive)

```bash
ROOT=/opt/iot-offline-opensuse15.6
LAB="$HOME/iot-vmware-laptop2-test"
export ROOT LAB

bash lab.sh prepare
```

The script searches for:

- **EMQX** executable under `$ROOT/repos/02-erlang-emqx/**/rel/emqx/bin/emqx`. If missing it can extract an `emqx589-editable-workspace.zip` found under `$ROOT/dist/emqx589/` or `$ROOT/offline-install-assets/emqx/`.
- **Kafka** executable under `$ROOT/repos/03-java-kafka/**/bin/kafka-server-start.sh`. If missing, it can reconstruct/extract the `kafka_2.13-3.9.2.tgz.part-000` + `part-001` files if they are placed under `$ROOT/offline-install-assets/kafka/` (or provided using `KAFKA_PARTS_DIR=`).
- **Node.js 22** executable already present under the ThingsBoard build's `msa/web-ui/target/node/node`, or a manually specified `NODE_SOURCE=`.

You can override discovery by setting `EMQX_HOME=`, `EMQX_WORKSPACE_ZIP=`, `KAFKA_HOME=`, `KAFKA_TARBALL=`, `KAFKA_PARTS_DIR=`, or `NODE_SOURCE=` to **local paths**. For example:

```bash
EMQX_HOME=/opt/iot-offline-opensuse15.6/repos/02-erlang-emqx/source/emqx/_build/emqx/rel/emqx \
KAFKA_HOME=/opt/iot-offline-opensuse15.6/runtime/kafka_2.13-3.9.2 \
bash lab.sh prepare
```

**Important:** Your GitHub EMQX release includes a source/compiled workspace and a cached **builder** image, not a guaranteed standalone broker image. The harness will report a missing compiled runtime if it cannot find `bin/emqx`. Running the compiled release in a copied directory may depend on native libraries and the build environment; the real startup test determines compatibility.

Expected lab structure:

```text
$LAB/
├── config/kafka.properties
├── data/
│   ├── kafka/                 # Created on first start only
│   ├── emqx/                  # Own EMQX node database
│   └── users/users.json       # Created by Node UI login bootstrap
├── runtime/
│   ├── kafka/
│   ├── emqx/
│   └── node
├── user-management/
│   ├── src/ public/ tests/ scripts/
│   └── .env                  # Owner-only generated test credentials
├── private/first-admin-password.txt
├── logs/
└── reports/
```

## 4. First startup and subsequent startup

**FIRST START ONLY** (creates *only* `$LAB/data/kafka`; never touches any existing Kafka cluster):

```bash
bash lab.sh start --initialize
```

**LATER STARTS** (preserves Kafka metadata, EMQX data and local users):

```bash
bash lab.sh start
```

**Never reformat an existing cluster.** The `--initialize` flag is honored only if the isolated lab directory lacks `meta.properties` **and is empty**. Do not delete Kafka `meta.properties` to force re-initialization.

Wait until the services are listening, then:

```bash
bash lab.sh status
bash lab.sh test
```

`start` writes per-service logs, and `test` generates a timestamped report at `$LAB/reports/test-*.log`. An unsuccessful component doesn't erase logs or data.

## 5. Open the UIs

**Node.js User Management:** [http://127.0.0.1:3001](http://127.0.0.1:3001)

- Username: `admin@local.test`
- Password: stored privately at `$LAB/private/first-admin-password.txt`. View locally with `cat "$LAB/private/first-admin-password.txt"`; change it after bootstrap. This test project does not create accounts in EMQX or ThingsBoard.
- Under **Integrations**, verify the MQTT and Kafka test buttons against ports **1884** and **9094**.

**EMQX Dashboard:** [http://127.0.0.1:18084](http://127.0.0.1:18084). If this EMQX is a clean first-time runtime, its initial account may be `admin` / `public`. Change it immediately. EMQX Dashboard credentials are separate from the Node.js administrator.

**ThingsBoard (existing VM service):** [http://127.0.0.1:8080](http://127.0.0.1:8080). Your previously initialized ThingsBoard database is reused **only for viewing and connectivity checks**.

Kafka does not have a built-in web UI in these release assets; the included Node.js UI includes broker diagnostics and message round-trip buttons.

## 6. What the automatic test checks

`bash lab.sh test` verifies nine distinct checks:

1. EMQX listener available at `1884`.
2. EMQX Dashboard HTTP available at `18084`.
3. **Actual MQTT CONNECT → SUBSCRIBE → PUBLISH → RECEIVE** test with the bundled Node.js MQTT packet code.
4. Kafka broker accepts TCP connections on `9094`.
5. **Actual Kafka topic creation, message production and message consumption** (and attempts to clean up test topic).
6. Node.js web application HTTP available on `3001`.
7. Node.js administrator **authenticated login** and service-status API.
8. Existing ThingsBoard login page responds on `8080`.
9. Existing PostgreSQL `pg_isready` (or TCP fallback) on `5432`.

A green HTTP/TCP status alone does **not** prove the protocol works: tests 3, 5 and 7 specifically exercise protocol and application behavior. The nine-test suite is not a ThingsBoard telemetry integration, EMQX→Kafka bridge, fresh PostgreSQL install, or production security certification.

## 7. Investigate failures

```bash
LAB="$HOME/iot-vmware-laptop2-test"

tail -100 "$LAB/logs/emqx-start.log" 2>/dev/null
tail -100 "$LAB/logs/kafka.log" 2>/dev/null
tail -100 "$LAB/logs/node.log" 2>/dev/null
ss -ltnp | grep -E ':1884|:18084|:9094|:9095|:3001|:8080|:5432' || true
```

| Error | Likely cause | Next action |
|---|---|---|
| `No compiled EMQX runtime found` | Only the builder/source artifacts were staged | Transfer compiled `rel/emqx` from first VM; use `EMQX_HOME=` |
| EMQX fails with `erl`/shared-library errors | Compiled runtime is not self-contained on this OS | Inspect `emqx-start.log`; transfer a fully packaged runtime or use offline container image with a proper broker release |
| EMQX port already used | A second lab process or misconfigured node is running | Check `ss -ltnp`, do not kill an unknown process |
| Kafka format refused | New lab directory contains unrelated/old files | Inspect `$LAB/data/kafka`; never delete blindly |
| Kafka broker cannot connect | Java missing, bad config, broker still starting | Inspect `kafka.log`; verify `java -version`, `9094` and `9095` |
| Node.js says `Set ADMIN_PASSWORD` | Missing generated `.env` or invalid credentials | Run `prepare`; inspect owner-only `.env` without pasting secrets |
| MQTT test denied | EMQX is enforcing authentication/ACLs | Set MQTT credentials for this test explicitly; do not disable production authentication |
| ThingsBoard fails but Node/EMQX/Kafka pass | Original ThingsBoard service is stopped | Check `systemctl status thingsboard`; this lab does not start/modify it |

## 8. Stop the test lab safely

```bash
bash lab.sh stop
```

Only test-specific Node/Kafka PIDs and the unique `emqx77@127.0.0.1` instance are targeted. The original ThingsBoard, PostgreSQL, original EMQX/Kafka instances, Maven caches and source folders are left alone. Stop does **not** delete the test folder or test data.

## 9. Before calling the second laptop fully offline-ready

This VM lab is an integration test, **not a substitute for a clean installation**. After it passes:

- Package/install the offline RPM dependencies into a fresh openSUSE 15.6 VM without networking.
- Start EMQX and Kafka on their standard deployment ports or intentionally assigned production ports.
- Install PostgreSQL, create a **new** ThingsBoard database, install your built ThingsBoard RPM and run the schema installer once on that new database.
- Deploy the Node.js User Management system, move its user records to PostgreSQL, and implement actual EMQX/ThingsBoard user provisioning.
- Run the end-to-end EMQX→Kafka→ThingsBoard telemetry path as a separate functional test, then collect logs and hashes for the full offline release.

**References:** [Your GitHub release page](https://github.com/Developer20003/iot-offline-opensuse15.6/releases), [EMQX configuration docs](https://docs.emqx.com/en/emqx/latest/guides/configuration/configuration.html), [Kafka 3.9 KRaft docs](https://kafka.apache.org/39/operations/kraft/).
