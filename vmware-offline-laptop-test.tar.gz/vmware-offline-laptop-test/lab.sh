#!/usr/bin/env bash
# Offline IoT VMware 'second laptop' smoke-test harness.
# No downloads, package installations, service restarts, or destructive operations.
set -Eeuo pipefail
umask 077
ROOT="${ROOT:-/opt/iot-offline-opensuse15.6}"
LAB="${LAB:-$HOME/iot-vmware-laptop2-test}"
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CMD="${1:-help}"
LOG="$LAB/logs"
DATA="$LAB/data"
RT="$LAB/runtime"
APP="$LAB/user-management"
KAFKA="$RT/kafka"
EMQX="$RT/emqx"
NODE="$RT/node"
KCFG="$LAB/config/kafka.properties"
EMQX_NODE_NAME="emqx77@127.0.0.1"
fail(){ echo "ERROR: $*" >&2; exit 1; }
note(){ echo "INFO: $*"; }
warn(){ echo "WARNING: $*" >&2; }
has(){ command -v "$1" >/dev/null 2>&1; }
check_port(){ timeout 2 bash -c 'echo > /dev/tcp/127.0.0.1/$1' _ "$1" >/dev/null 2>&1; }
check_http(){ if ! has curl; then return 1; fi; local c; c="$(curl --noproxy '*' --connect-timeout 2 --max-time 5 -sS -o /dev/null -w '%{http_code}' "$1" 2>/dev/null)" || return 1; [[ "$c" == 2* || "$c" == 3* ]]; }
init_dirs(){ mkdir -p "$LOG" "$DATA" "$RT" "$LAB/config" "$LAB/private" "$LAB/reports"; }
find_emqx(){
  if [[ -n "${EMQX_HOME:-}" && -f "$EMQX_HOME/bin/emqx" ]]; then printf '%s\n' "$EMQX_HOME"; return; fi
  local found=""
  if [[ -d "$ROOT/repos/02-erlang-emqx" ]]; then
    found="$(find "$ROOT/repos/02-erlang-emqx" -type f -path '*/rel/emqx/bin/emqx' -print -quit 2>/dev/null || true)"
  fi
  [[ -z "$found" ]] || printf '%s\n' "${found%/bin/emqx}"
}
find_kafka(){
  if [[ -n "${KAFKA_HOME:-}" && -f "$KAFKA_HOME/bin/kafka-server-start.sh" ]]; then printf '%s\n' "$KAFKA_HOME"; return; fi
  local base found=""
  for base in "$ROOT/repos/03-java-kafka" "$ROOT/runtime"; do
    [[ -d "$base" ]] || continue
    found="$(find "$base" -type f -path '*/bin/kafka-server-start.sh' -print -quit 2>/dev/null || true)"
    [[ -z "$found" ]] || { printf '%s\n' "${found%/bin/kafka-server-start.sh}"; return; }
  done
}
find_node(){
  local c
  for c in "${NODE_SOURCE:-}" "$ROOT/repos/05-nodejs-pnpm/user-management/runtime/node" \
     "$ROOT/repos/04-thingsboard/source/thingsboard/msa/web-ui/target/node/node" \
     "$ROOT/repos/04-thingsboard/source/thingsboard/ui-ngx/target/node/node"; do
    [[ -n "$c" && -x "$c" ]] || continue
    case "$("$c" -v 2>/dev/null || true)" in v22.*) printf '%s\n' "$c"; return ;; esac
  done
  if has node && [[ "$(node -v)" == v22.* ]]; then command -v node; fi
}
find_archive(){
  local name="$1" c
  for c in "${ASSET_DIR:-/nonexistent}/$name" "$ROOT/dist/emqx589/$name" \
      "$ROOT/offline-install-assets/emqx/$name" "$ROOT/offline-install-assets/kafka/$name" \
      "$ROOT/dist/kafka392/$name" "$ROOT/dist/kafka392/upload/$name" \
      "$ROOT/dist/kafka-3.9.2/$name" "$ROOT/dist/kafka-3.9.2/upload/$name"; do
    [[ -f "$c" ]] && { printf '%s\n' "$c"; return; }
  done
}
write_kafka_config(){
  [[ -e "$KCFG" ]] && { note "Existing Kafka test configuration retained: $KCFG"; return; }
  cat > "$KCFG" <<EOF
# Isolated local-only KRaft node. Do not use for production.
process.roles=broker,controller
node.id=77
controller.quorum.voters=77@127.0.0.1:9095
controller.listener.names=CONTROLLER
listeners=PLAINTEXT://127.0.0.1:9094,CONTROLLER://127.0.0.1:9095
advertised.listeners=PLAINTEXT://127.0.0.1:9094
listener.security.protocol.map=CONTROLLER:PLAINTEXT,PLAINTEXT:PLAINTEXT
inter.broker.listener.name=PLAINTEXT
log.dirs=$DATA/kafka
num.partitions=1
auto.create.topics.enable=false
offsets.topic.replication.factor=1
transaction.state.log.replication.factor=1
transaction.state.log.min.isr=1
group.initial.rebalance.delay.ms=0
EOF
  note "Created isolated Kafka config $KCFG"
}
copy_kafka(){
  if [[ -f "$KAFKA/bin/kafka-server-start.sh" && -f "$KAFKA/bin/kafka-storage.sh" ]]; then note 'Kafka runtime already staged';return;fi
  local src tgz p0 p1 partdir
  src="$(find_kafka || true)"
  if [[ -n "$src" ]]; then
    note "Copying runnable Kafka distribution: $src"
    mkdir -p "$KAFKA"; cp -a "$src/." "$KAFKA/"
  else
    tgz="${KAFKA_TARBALL:-}"
    [[ -f "$tgz" ]] || tgz="$(find_archive kafka_2.13-3.9.2.tgz || true)"
    if [[ -z "$tgz" ]]; then
      p0="${KAFKA_PARTS_DIR:-}/kafka_2.13-3.9.2.tgz.part-000"
      [[ -f "$p0" ]] || p0="$(find_archive kafka_2.13-3.9.2.tgz.part-000 || true)"
      if [[ -n "$p0" && -f "$p0" ]]; then
        partdir="$(dirname "$p0")"
        p1="$partdir/kafka_2.13-3.9.2.tgz.part-001"
        [[ -f "$p1" ]] || { warn "Kafka part-001 missing in $partdir"; return 1; }
        if [[ -f "$partdir/SHA256SUMS-parts.txt" ]]; then
          note 'Checking Kafka release part hashes'
          (cd "$partdir" && grep -E 'kafka_2\.13-3\.9\.2\.tgz\.part-00[01]$' SHA256SUMS-parts.txt | sha256sum -c -) || return 1
        else warn 'Kafka part checksum manifest missing; verify source USB files manually'; fi
        mkdir -p "$LAB/staging"
        tgz="$LAB/staging/kafka_2.13-3.9.2.tgz"
        [[ -f "$tgz" ]] || cat "$p0" "$p1" > "$tgz"
        if [[ -f "$partdir/SHA256-ORIGINALS.txt" ]]; then
          note 'Checking reconstructed Kafka archive hash'
          (cd "$LAB/staging" && grep -E 'kafka_2\.13-3\.9\.2\.tgz$' "$partdir/SHA256-ORIGINALS.txt" | sha256sum -c -) || return 1
        fi
      fi
    fi
    if [[ -n "$tgz" && -f "$tgz" ]]; then
      note "Extracting Kafka binary archive $tgz"
      mkdir -p "$LAB/staging/kafka-extracted"
      tar -xzf "$tgz" -C "$LAB/staging/kafka-extracted" || return 1
      src="$LAB/staging/kafka-extracted/kafka_2.13-3.9.2"
      [[ -f "$src/bin/kafka-server-start.sh" ]] || { warn 'Kafka distribution not found in archive'; return 1; }
      mkdir -p "$KAFKA"; cp -a "$src/." "$KAFKA/"
    else
      warn 'Kafka runtime missing. Put split Kafka distribution in ROOT/offline-install-assets/kafka, or set KAFKA_HOME.'
      return 1
    fi
  fi
  [[ -f "$KAFKA/bin/kafka-server-start.sh" && -f "$KAFKA/bin/kafka-storage.sh" ]] || return 1
  [[ -d "$KAFKA/libs" ]] || { warn 'Kafka libs missing: this may be source, not runnable distribution'; return 1; }
  chmod u+x "$KAFKA/bin/"*.sh
  note "Kafka runtime staged at $KAFKA"
}
copy_emqx(){
  if [[ -x "$EMQX/bin/emqx" ]]; then note 'EMQX runtime already staged';return;fi
  local src zipfile path
  src="$(find_emqx || true)"
  if [[ -z "$src" ]]; then
    zipfile="${EMQX_WORKSPACE_ZIP:-}"
    [[ -f "$zipfile" ]] || zipfile="$(find_archive emqx589-editable-workspace.zip || true)"
    if [[ -n "$zipfile" && -f "$zipfile" ]] && has unzip; then
      note "Extracting EMQX editable workspace locally: $zipfile"
      mkdir -p "$LAB/staging/emqx-extracted"
      if [[ ! -f "$LAB/staging/emqx-extracted/.extracted-ok" ]]; then
        unzip -q "$zipfile" -d "$LAB/staging/emqx-extracted" || return 1
        touch "$LAB/staging/emqx-extracted/.extracted-ok"
      fi
      path="$(find "$LAB/staging/emqx-extracted" -type f -path '*/rel/emqx/bin/emqx' -print -quit || true)"
      [[ -z "$path" ]] || src="${path%/bin/emqx}"
    fi
  fi
  if [[ -z "$src" ]]; then
    warn 'No compiled EMQX runtime found. The cached Docker BUILDER is not a running broker image.'
    warn 'Build/export the full rel/emqx runtime from the first VM, or set EMQX_HOME to a compiled release.'
    return 1
  fi
  note "Copying compiled EMQX runtime: $src"
  mkdir -p "$EMQX"; cp -a "$src/." "$EMQX/"
  chmod u+x "$EMQX/bin/emqx"
  note "EMQX release staged at $EMQX (native portability still needs runtime testing)"
}
copy_node(){
  [[ -d "$APP/src" ]] || { mkdir -p "$APP"; (cd "$PKG/user-management" && tar -cf - --exclude=.env --exclude=users.json --exclude=node_modules .) | (cd "$APP" && tar -xf -); }
  if [[ -x "$NODE" ]];then note "Node already staged: $("$NODE" -v)";return;fi
  local src
  src="$(find_node || true)"
  [[ -n "$src" ]] || { warn 'Node.js 22 binary missing. Copy Node runtime into ROOT or set NODE_SOURCE'; return 1; }
  cp -a "$src" "$NODE";chmod u+x "$NODE"
  mkdir -p "$APP/runtime"
  [[ -e "$APP/runtime/node" ]] || ln -s ../../runtime/node "$APP/runtime/node"
  note "Node $("$NODE" -v) copied from $src"
}
make_env(){
  [[ -f "$APP/.env" ]] && { note 'Existing admin credentials retained';return; }
  local secret
  [[ -x "$NODE" ]] || { warn 'Cannot generate .env without Node';return 1; }
  secret="$("$NODE" -e 'process.stdout.write(require("node:crypto").randomBytes(24).toString("hex"))')"
  cat > "$APP/.env" <<EOF
HOST=127.0.0.1
PORT=3001
USER_DATA_DIR=$DATA/users
ADMIN_EMAIL=admin@local.test
ADMIN_PASSWORD=$secret
EMQX_HOST=127.0.0.1
EMQX_PORT=1884
EMQX_DASHBOARD_URL=http://127.0.0.1:18084
MQTT_USERNAME=
MQTT_PASSWORD=
KAFKA_HOST=127.0.0.1
KAFKA_PORT=9094
KAFKA_TOPICS_BIN=$KAFKA/bin/kafka-topics.sh
TB_URL=http://127.0.0.1:8080
TB_USERNAME=
TB_PASSWORD=
PG_HOST=127.0.0.1
PG_PORT=5432
EOF
  chmod 600 "$APP/.env"
  printf '%s\n' "$secret" > "$LAB/private/first-admin-password.txt"
  chmod 600 "$LAB/private/first-admin-password.txt"
  note 'Created private administrator credentials; see LAB/private/first-admin-password.txt'
}
prepare(){
  init_dirs
  note "Isolated VMware simulated second-laptop directory: $LAB"
  [[ -d "$ROOT" ]] || warn "Offline repo missing: $ROOT"
  [[ "$(uname -m)" == x86_64 ]] || warn 'Target expected x86_64 Linux'
  [[ -f /etc/os-release ]] && { grep -E '^(NAME|VERSION_ID)=' /etc/os-release || true; }
  if has java;then java -version 2>&1 | head -3;else warn 'Java missing: Kafka cannot start';fi
  local missing=0
  copy_kafka || missing=$((missing+1))
  [[ -f "$KAFKA/bin/kafka-server-start.sh" ]] && write_kafka_config
  copy_emqx || missing=$((missing+1))
  copy_node || missing=$((missing+1))
  [[ -x "$NODE" ]] && make_env || true
  note 'Checking completed stages:'
  [[ -x "$EMQX/bin/emqx" ]] && echo '  EMQX: STAGED' || echo '  EMQX: MISSING'
  [[ -f "$KAFKA/bin/kafka-server-start.sh" ]] && echo '  Kafka: STAGED' || echo '  Kafka: MISSING'
  [[ -x "$NODE" && -f "$APP/.env" ]] && echo '  Node UI: STAGED' || echo '  Node UI: MISSING'
  if [[ -x "$NODE" ]]; then (cd "$APP" && "$NODE" --test tests/*.test.js) || missing=$((missing+1)); fi
  if (( missing ));then warn "$missing preflight component(s) missing or failed. No existing services or data were changed.";return 1;fi
  note 'PREPARE COMPLETE: use lab.sh start --initialize ONCE, then lab.sh test'
}
emqx_cmd(){
  env EMQX_NODE__NAME="$EMQX_NODE_NAME" \
      EMQX_NODE__DATA_DIR="$DATA/emqx" \
      EMQX_LISTENERS__TCP__DEFAULT__BIND='127.0.0.1:1884' \
      EMQX_LISTENERS__SSL__DEFAULT__ENABLE=false \
      EMQX_LISTENERS__WS__DEFAULT__ENABLE=false \
      EMQX_LISTENERS__WSS__DEFAULT__ENABLE=false \
      EMQX_DASHBOARD__LISTENERS__HTTP__BIND='127.0.0.1:18084' \
      EMQX_DASHBOARD__LISTENERS__HTTPS__ENABLE=false \
      "$EMQX/bin/emqx" "$@"
}
start_kafka(){
  [[ -f "$KAFKA/bin/kafka-server-start.sh" ]] || { warn 'Kafka not staged';return 1; }
  [[ -f "$KCFG" ]] || { warn 'Kafka config missing: run prepare';return 1; }
  if check_port 9094 || check_port 9095;then warn 'Port 9094 or 9095 already in use. No Kafka process started; inspect ss -ltnp.';return 1;fi
  if [[ ! -f "$DATA/kafka/meta.properties" ]]; then
    [[ "${1:-}" == '--initialize' ]] || { warn 'New KRaft data requires explicit: lab.sh start --initialize'; return 1; }
    mkdir -p "$DATA/kafka"
    [[ -z "$(ls -A "$DATA/kafka")" ]] || { warn 'Kafka data not empty. Refusing to format';return 1; }
    note 'Formatting only the new test Kafka data directory'
    local id
    id="$("$KAFKA/bin/kafka-storage.sh" random-uuid)" || return 1
    "$KAFKA/bin/kafka-storage.sh" format -t "$id" -c "$KCFG" || return 1
  fi
  note 'Starting isolated Kafka 9094 (KRaft controller 9095)'
  (export KAFKA_HEAP_OPTS='-Xms256m -Xmx768m'; nohup "$KAFKA/bin/kafka-server-start.sh" "$KCFG" > "$LOG/kafka.log" 2>&1 < /dev/null & echo $! > "$LAB/kafka.pid")
}
start_emqx(){
  [[ -x "$EMQX/bin/emqx" ]] || { warn 'EMQX compiled release missing'; return 1; }
  if check_port 1884 || check_port 18084;then warn 'EMQX test ports 1884/18084 occupied; not starting';return 1;fi
  note "Starting isolated EMQX node $EMQX_NODE_NAME"
  (cd "$EMQX" && emqx_cmd start) > "$LOG/emqx-start.log" 2>&1 || { warn "EMQX startup failed. See $LOG/emqx-start.log"; return 1; }
}
start_node(){
  [[ -x "$NODE" && -f "$APP/.env" ]] || { warn 'Node UI missing. Run prepare';return 1; }
  if check_port 3001;then warn 'Port 3001 occupied; will not start second Node instance';return 1;fi
  note 'Starting Node.js User Management UI on port 3001'
  (nohup "$NODE" "$APP/src/server.js" > "$LOG/node.log" 2>&1 < /dev/null & echo $! > "$LAB/node.pid")
}
start(){
  init_dirs
  local rc=0
  start_kafka "$@" || rc=1
  start_emqx || rc=1
  start_node || rc=1
  note 'Started requested components (or logged failures). Run lab.sh test after services settle.'
  [[ $rc == 0 ]]
}
status(){
  init_dirs
  echo '=== ISOLATED OFFLINE LAB STATUS ==='
  echo "LAB=$LAB"
  echo "ROOT=$ROOT"
  echo 'PORTS (test: 1884 MQTT, 18084 dashboard, 9094 Kafka, 9095 controller, 3001 UI):'
  if has ss;then ss -ltnp | grep -E ':1884|:18084|:9094|:9095|:3001|:8080|:5432' || true;fi
  for i in 1884 18084 9094 9095 3001 8080 5432;do
    if check_port "$i";then printf '  %s: OPEN\n' "$i";else printf '  %s: CLOSED\n' "$i";fi
  done
  echo 'LOG FILES:'
  find "$LOG" -maxdepth 1 -type f -printf '  %f\n' | sort
}
checks=0;passed=0
check(){
  local label="$1";shift
  checks=$((checks+1))
  if "$@";then echo "PASS: $label";passed=$((passed+1));else echo "FAIL: $label";fi
}
test_node_login(){
  [[ -x "$NODE" && -f "$APP/.env" ]] || return 1
  LAB_NODE_APP="$APP" "$NODE" - <<'NODEJS'
const fs=require('node:fs');
const path=process.env.LAB_NODE_APP;
const cfg=require(path+'/src/config.js');
(async()=>{
 const base='http://127.0.0.1:3001';
 const r=await fetch(base+'/api/login',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({email:cfg.adminEmail,password:cfg.adminPassword}),signal:AbortSignal.timeout(5000)});
 if(!r.ok)throw Error('Node login HTTP '+r.status);
 const cookie=(r.headers.get('set-cookie')||'').split(';')[0];
 const s=await fetch(base+'/api/status',{headers:{cookie},signal:AbortSignal.timeout(5000)});
 if(!s.ok)throw Error('Node status HTTP '+s.status);
 const d=await s.json();if(!d.services)throw Error('Missing services JSON');
 console.log('  User login + authenticated service status: OK');
})().catch(e=>{console.error('  '+e.message);process.exitCode=1});
NODEJS
}
test_mqtt(){
  [[ -x "$NODE" ]] || return 1
  LAB_NODE_APP="$APP" "$NODE" - <<'NODEJS'
const {mqttSmoke}=require(process.env.LAB_NODE_APP+'/src/mqtt.js');
mqttSmoke({host:'127.0.0.1',port:1884}).then(r=>console.log('  '+r.description)).catch(e=>{console.error('  '+e.message);process.exitCode=1});
NODEJS
}
test_kafka(){
  [[ -f "$KAFKA/bin/kafka-topics.sh" ]] || return 1
  local topic="vmtest.$(date +%s).$$" marker="vmware-offline-kafka-$(date +%s)-$$" received
  timeout 25 "$KAFKA/bin/kafka-topics.sh" --bootstrap-server 127.0.0.1:9094 --create --topic "$topic" --partitions 1 --replication-factor 1 >/dev/null || return 1
  printf '%s\n' "$marker" | timeout 25 "$KAFKA/bin/kafka-console-producer.sh" --bootstrap-server 127.0.0.1:9094 --topic "$topic" >/dev/null || return 1
  received="$(timeout 25 "$KAFKA/bin/kafka-console-consumer.sh" --bootstrap-server 127.0.0.1:9094 --topic "$topic" --from-beginning --max-messages 1 --timeout-ms 12000 2> "$LOG/kafka-consumer-last.log")" || return 1
  timeout 12 "$KAFKA/bin/kafka-topics.sh" --bootstrap-server 127.0.0.1:9094 --delete --topic "$topic" >/dev/null 2>&1 || true
  [[ "$received" == "$marker" ]] || { warn "Kafka received unexpected content: $received";return 1; }
  echo "  Kafka produced and consumed identical marker: $marker"
}
test(){
  init_dirs
  note 'Real broker tests (not just port probes). All endpoints are localhost.'
  check 'EMQX MQTT TCP listener on 1884' check_port 1884
  check 'EMQX Dashboard HTTP on 18084' check_http 'http://127.0.0.1:18084/'
  check 'EMQX MQTT CONNECT + SUBSCRIBE + PUBLISH + RECEIVE' test_mqtt
  check 'Kafka broker TCP 9094' check_port 9094
  check 'Kafka create/produce/consume/delete isolated topic' test_kafka
  check 'Node UI HTTP 3001' check_http 'http://127.0.0.1:3001/'
  check 'Node administrator login + status API' test_node_login
  check 'Existing ThingsBoard web UI 8080' check_http 'http://127.0.0.1:8080/login'
  if has pg_isready;then check 'Existing PostgreSQL local readiness' pg_isready -h 127.0.0.1 -p 5432 -q;else check 'Existing PostgreSQL port 5432' check_port 5432;fi
  echo "=== RESULT: $passed / $checks checks passed ==="
  echo "NOTE: ThingsBoard and PostgreSQL are EXISTING services, not cloned into this test directory."
  [[ "$passed" == "$checks" ]]
}
stop(){
  init_dirs
  local p cmd
  if [[ -f "$LAB/node.pid" ]];then
    p="$(cat "$LAB/node.pid")"
    if [[ "$p" =~ ^[0-9]+$ ]] && kill -0 "$p" 2>/dev/null;then
      cmd="$(ps -p "$p" -o args= || true)"
      if [[ "$cmd" == *"$APP/src/server.js"* ]];then kill "$p";note "Stopped test Node PID=$p";else warn 'Node PID belongs to an unexpected process; not stopping it';fi
    fi
    rm -f "$LAB/node.pid"
  fi
  if [[ -f "$LAB/kafka.pid" ]];then
    p="$(cat "$LAB/kafka.pid")"
    if [[ "$p" =~ ^[0-9]+$ ]] && kill -0 "$p" 2>/dev/null;then
      cmd="$(ps -p "$p" -o args= || true)"
      if [[ "$cmd" == *"$KCFG"* ]];then kill "$p";note "Stopped test Kafka PID=$p";else warn 'Kafka PID belongs to an unexpected process; not stopping it';fi
    fi
    rm -f "$LAB/kafka.pid"
  fi
  if [[ -x "$EMQX/bin/emqx" ]];then
    (cd "$EMQX" && emqx_cmd stop) > "$LOG/emqx-stop.log" 2>&1 && note 'Requested stop of test EMQX node' || warn 'EMQX stop was unsuccessful; inspect EMQX node state'
  fi
  note 'Existing ThingsBoard and PostgreSQL services were not touched.'
}
case "$CMD" in
 prepare) prepare;;
 start) shift; start "$@";;
 test) init_dirs; test | tee -a "$LAB/reports/test-$(date +%Y%m%d-%H%M%S).log"; exit "${PIPESTATUS[0]}";;
 status) status;;
 stop) stop;;
 help|--help|-h) cat <<EOF
Offline VMware simulated second-laptop lab
Usage: ROOT=/opt/iot-offline-opensuse15.6 LAB=\$HOME/iot-vmware-laptop2-test bash lab.sh <command>
Commands:
  prepare              Copy local EMQX, Kafka, Node binaries into isolated test directory
  start --initialize   First startup ONLY: format NEW lab Kafka data, start Kafka, EMQX and Node
  start                Subsequent startup, preserving Kafka metadata and user accounts
  test                 Test MQTT pub/sub, Kafka produce/consume, Node UI/auth, existing ThingsBoard/PG
  status               Read-only port and log status
  stop                 Stop only lab-owned processes (not system services)
Optional variables: EMQX_HOME, EMQX_WORKSPACE_ZIP, KAFKA_HOME, KAFKA_TARBALL, KAFKA_PARTS_DIR, NODE_SOURCE, ASSET_DIR
EOF
 ;;
 *) fail "Unknown command '$CMD'. Use help";;
esac
