'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const net=require('node:net');
const {mqttSmoke,extract,packet}=require('../src/mqtt');
test('MQTT smoke test completes real PUB/SUB socket exchange against a stub broker',async()=>{
  const sockets=new Set();
  const server=net.createServer(socket=>{
    sockets.add(socket);socket.on('close',()=>sockets.delete(socket));
    let buf=Buffer.alloc(0),topic='';
    socket.on('data',chunk=>{
      buf=Buffer.concat([buf,chunk]);let p;
      while((p=extract(buf))){buf=buf.subarray(p.length);
        if(p.type===1)socket.write(Buffer.from([0x20,2,0,0]));
        else if(p.type===8){
          const len=p.body.readUInt16BE(2);topic=p.body.subarray(4,4+len).toString();
          socket.write(Buffer.from([0x90,3,0,1,0]));
        }else if(p.type===3){socket.write(packet(0x30,p.body));}
      }
    });
  });
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  try{
    const info=await mqttSmoke({host:'127.0.0.1',port:server.address().port});
    assert.equal(info.ok,true);
    assert.match(info.topic,/^lab\/ums\/smoke\//);
  }finally{for(const s of sockets)s.destroy();await new Promise(resolve=>server.close(resolve));}
});
