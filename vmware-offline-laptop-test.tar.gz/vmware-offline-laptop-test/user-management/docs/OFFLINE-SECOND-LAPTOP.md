# Offline setup handbook — second openSUSE Leap 15.6 laptop

This handbook is written for the prepared directory `/opt/iot-offline-opensuse15.6` and the proven ThingsBoard CE **4.3.1.8** / PostgreSQL **16.13** stack. EMQX **5.8.9 CE** and Kafka were collected on the first computer but their runtime availability and message path are **not yet proven** on the second one. **Nothing here downloads packages.**

## A. What must travel to the offline computer

Transfer the whole existing 19 GB `/opt/iot-offline-opensuse15.6` tree, **after adding this project** with `scripts/stage-on-preparation-machine.sh`. Preserve file permissions, symbolic links, `repos/02-erlang-emqx`, `repos/03-java-kafka`, and `repos/04-thingsboard` caches/artifacts. A checksum manifest is not a package by itself.

Before generating the final archive on the first computer:

1. Use `bash scripts/stage-on-preparation-machine.sh` from this project; it places the app and a working Node 22 binary in `repos/05-nodejs-pnpm/user-management`.
2. Download the official VS Code RPM on the first computer and store under `repos/08-vscode/rpms`. It is *not* included in this project ZIP. Prefer the earlier release toolkit's `scripts/download-vscode-rpm.sh`.
3. Verify that EMQX has its compiled release at `repos/02-erlang-emqx/source/emqx/_build/emqx/rel/emqx/bin/emqx`. If using Docker builder images, also save them with `docker save` and prepare the offline Docker engine; a Git checkout alone will not run a broker.
4. Verify that a runnable Kafka distribution contains `bin/kafka-server-start.sh`, `bin/kafka-topics.sh`, and all Kafka libraries. Source files alone are insufficient.
5. Transfer all RPMs needed to install Java 17, PostgreSQL 16, Docker (if required), and VS Code on **this specific target system**. Some dependency RPMs may already be in the laptop's base OS installation, so testing on the clean laptop is necessary.
6. Rebuild `offline-release/repositories.sha256` after staging and adding VS Code. Verify the final archive after extraction. Never include `.env`, `~/.local/state/offline-iot-user-management/users.json`, database passwords, or live `/var/lib/pgsql` data files in published releases.

## B. Extracting and verification

Restore the archive to **exactly** `/opt/iot-offline-opensuse15.6`. The ThingsBoard root POM contains absolute Gradle paths. If the archive is in the usual `.tar.zst` format, decompress it with `tar --zstd -xf <archive> -C /opt` or `zstd -dc <archive> | tar -xf - -C /opt` depending on available tar version. Make sure the archive contains the top-level `iot-offline-opensuse15.6/` folder rather than another nested layer.

```bash
ROOT=/opt/iot-offline-opensuse15.6
cd "$ROOT" || exit 1
sha256sum -c offline-release/build-artifacts.sha256
# Full verification is expensive and checks >500,000 files. Use on a quiescent copy:
sha256sum -c offline-release/repositories.sha256 > /tmp/ums-verify.log 2>&1
printf 'Verification result: %s\n' "$?"
```

Warning: a full repository manifest generated before staging this project or downloading VS Code will not include the added files. Regenerate on the preparation machine just before packing. If rebuilding alters cached files, re-run the checksums.

## C. Install system packages without internet

On the target laptop first identify missing packages, then install from the offline RPM collection. Avoid invoking unpinned online repos or `curl | sh`. Your ThingsBoard package exists at:

`$ROOT/repos/04-thingsboard/source/thingsboard/application/target/thingsboard.rpm`

On a target where Java 17 and its dependencies are already installed:

```bash
rpm -Uvh --test "$ROOT/repos/04-thingsboard/source/thingsboard/application/target/thingsboard.rpm"
rpm -Uvh "$ROOT/repos/04-thingsboard/source/thingsboard/application/target/thingsboard.rpm"
```

If `--test` reports missing dependencies, **do not use `--nodeps`**. Install missing RPMs from `repos/01-linux-base/rpms` using a validated local repository and dependency solver; the included `createrepo_c` RPM can create local metadata after its own dependencies are installed. Base RPMs across different Leap patch levels may conflict; use a VM or clean second laptop to verify.

### PostgreSQL

ThingsBoard's installed server needs PostgreSQL **16**. The first machine had `postgresql16-server` and `postgresql16`; verify the target:

```bash
rpm -q postgresql16 postgresql16-server
systemctl status postgresql --no-pager
pg_isready -h 127.0.0.1 -p 5432
```

On a **fresh** PostgreSQL server only, initialize through the distribution's documented workflow. Never run `initdb` over an existing `data` directory. Create a dedicated `thingsboard` PostgreSQL role/database, configure local TCP SCRAM password authentication, then edit `/usr/share/thingsboard/conf/thingsboard.conf` and run ThingsBoard `bin/install/install.sh` **once**. The first computer already installed and initialized ThingsBoard with **67 public tables**; that live DB is *not* embedded in the release. See the preceding ThingsBoard installation guide for exact steps.

### VS Code

```bash
find "$ROOT/repos" -name 'code-*.rpm' -print
# Test dependency resolution before installing:
rpm -Uvh --test /path/to/code-*.rpm
rpm -Uvh /path/to/code-*.rpm
```

No internet repositories should be required for an already-resolved set of local RPMs. You can use `code --extensions-dir "$ROOT/development/vscode-extensions" --install-extension /path/to/extension.vsix` for extensions staged as files.

## D. First-time Kafka KRaft startup (single laptop only)

Open **Terminal 1**:

```bash
ROOT=/opt/iot-offline-opensuse15.6
APP="$ROOT/repos/05-nodejs-pnpm/user-management"
# Only for a NEW Kafka data directory; never against an existing Kafka cluster.
bash "$APP/scripts/start-kafka-offline.sh" --initialize
```

This creates a persistent config under `$ROOT/runtime/kafka/server.properties`, uses `127.0.0.1:9092` and controller port 9093, and stores KRaft data in `$ROOT/runtime/kafka/kraft-logs`. It does not alter the supplied Kafka distribution's source configs. Subsequent starts:

```bash
bash "$APP/scripts/start-kafka-offline.sh"
```

If the tool says no Kafka distribution exists, first verify `repos/03-java-kafka` contains an extracted **binary** distribution. Kafka `4.x` may require different controller quorum settings than Kafka `3.x`; the script tests the template and will request initialization rather than overwriting an existing cluster. Do not format a reused data directory.

To check Kafka's *actual message path* rather than its TCP port:

```bash
bash "$APP/scripts/kafka-smoke.sh"
```

The script creates one temporary topic, publishes a random marker, consumes it back, verifies equality, and requests topic deletion. It needs a functioning single broker with plaintext localhost access. If your broker requires SASL/TLS, adapt the CLI client options first.

## E. EMQX runtime startup

Open **Terminal 2**:

```bash
bash "$APP/scripts/start-emqx-offline.sh"
```

This uses an installed `emqx.service` when present, otherwise the **compiled release** from your EMQX 5.8.9 source workspace. It refuses to launch another broker if port `1883` is occupied. EMQX Dashboard is normally available at `http://127.0.0.1:18083` (change the default admin password). MQTT authentication may be disabled in a bare initial EMQX install—enable broker authentication and topic ACLs before connecting non-test devices.

**Port collision:** ThingsBoard can also bind MQTT port `1883`. Confirm the actual owner using `ss -ltnp | grep ':1883'`. Keep EMQX at 1883 and move ThingsBoard's native MQTT transport to another port *only if required* by your architecture. The API UI on ThingsBoard port 8080 is separate.

## F. ThingsBoard and the new Node.js management UI

After PostgreSQL is configured and ThingsBoard is installed:

```bash
systemctl start postgresql
systemctl start thingsboard
```

Open **Terminal 3**:

```bash
cd "$APP"
cp -n .env.example .env
chmod 600 .env
vi .env   # set ADMIN_PASSWORD (12+ chars), and correct local host/port addresses
bash scripts/start-node-offline.sh
```

Log into **http://127.0.0.1:3000** with the `ADMIN_EMAIL` and `ADMIN_PASSWORD` from the first startup. It seeds a local `~/.local/state/offline-iot-user-management/users.json`, storing **scrypt password hashes** rather than plaintext. **Remove `ADMIN_PASSWORD` from `.env` after successful first boot**; the saved account will continue to work. Save the current user store separately if you need its users on a future laptop; the release intentionally excludes user data.

The Node.js UI has `Overview`, `Users`, and `Integrations` pages. It can **create, disable, enable, and list local users**. It does NOT provision ThingsBoard or EMQX identities yet; do not assume identity synchronization. Default web bind address is `127.0.0.1`, which is safe for a local development desktop. Use HTTPS and stronger multi-user authentication before any external deployment.

## G. Verify each connection independently

| Component | UI endpoint | Real protocol check |
|---|---|---|
| Node.js user management | `http://127.0.0.1:3000` | Login; create operator user; disable user |
| EMQX | `http://127.0.0.1:18083` | Node Integrations: MQTT PUB/SUB round-trip |
| Kafka | none bundled | `bash scripts/kafka-smoke.sh` (produce/consume) |
| ThingsBoard | `http://127.0.0.1:8080` | Login and open your System Admin dashboard |
| PostgreSQL | none bundled | `pg_isready -h 127.0.0.1 -p 5432` |

The Node Integrations page also offers an optional Kafka CLI admin check (requires `KAFKA_TOPICS_BIN` set in `.env`), ThingsBoard REST login (`TB_USERNAME`,`TB_PASSWORD`) and EMQX REST key test (`EMQX_API_KEY`,`EMQX_API_SECRET`). For a fully validated data pipeline, use a separate telemetry integration service. User-management API operations do not automatically flow through EMQX or Kafka.

## H. Common errors from the preparation machine and second laptop

| Error | Explanation | Safe action |
|---|---|---|
| `Could not install Gradle distribution ... 7.3.3` | Gradle Maven plugin attempted network download | Use preserved `gradle-distribution/gradle-7.3.3` and modified POM pointing to local installation |
| `Ident authentication failed for user thingsboard` | PostgreSQL `pg_hba.conf` chose `ident` for TCP before password auth | Add specific `host thingsboard thingsboard 127.0.0.1/32 scram-sha-256` **before** broad ident rule, validate/reload; do not erase all rules |
| `Invalid email format` on ThingsBoard login | ThingsBoard uses an email address, not literal `admin` | Use the authorized ThingsBoard account email |
| `Could not resolve dependencies offline` | RPM/Maven/Yarn/Gradle cache incomplete or path wrong | Check specific missing package/version, never clear caches during diagnosis |
| `Port 1883 already in use` | ThingsBoard and EMQX both may claim MQTT listener | Identify owner with `ss -ltnp`, then use distinct listener ports |
| `KRaft storage is not formatted` | First Kafka startup lacks `meta.properties` | Initialize only a brand-new Kafka data directory using `--initialize` |
| `KAFKA_TOPICS_BIN not configured` | Node UI cannot find Kafka CLI | Set absolute `kafka-topics.sh` path in `.env`; TCP probe can still work |
| `MQTT round-trip timeout` | EMQX connection/ACL issues, subscribe denied, broker down | Check EMQX logs, credentials, ACL, correct MQTT port; Node test needs publish & subscribe |
| `ADMIN_PASSWORD` placeholder | No secret seeded on first boot | Set 12+ char password; do not use default passwords |
| `Module not found` | Wrong startup command or missing JS files | Use `bash scripts/start-node-offline.sh`; this project has **no npm dependencies** |

## I. Recommended development progression

1. **Now:** run Kafka, EMQX, ThingsBoard; verify each UI and API. Launch local Node user management with zero downloads.
2. **Next:** implement a separate `user_management` PostgreSQL database (the JSON store here is a prototype), migrations and backups.
3. **Next:** add **ThingsBoard REST provisioning** for tenant admins, customer users, and devices, with mapping tables, retry handling, and audit logs. Do not write into ThingsBoard internal PostgreSQL tables.
4. **Next:** configure EMQX HTTP authentication/authorization against a hardened Node backend for **MQTT device identities**, distinct from human UI users.
5. **Next:** integrate KafkaJS (staged from an online package cache or vendor snapshot) to emit `users.events`, `devices.events`, `system.audit` messages and consume integration events with an outbox pattern.
6. **Later:** add Elasticsearch/OpenSearch as an index for searching logs, alarms and selected events; continue to treat PostgreSQL/ThingsBoard as the authoritative state. Plan index mappings, event schema, retention, role-aware queries, deletion propagation, and disk budget. Do not treat Elasticsearch as a drop-in ThingsBoard datastore.
7. **Before production:** TLS, secrets management, backup/restore, MFA/SSO, rate limiting, role enforcement, access controls, monitoring, and security testing.

## J. Offlining VS Code development and builds

The app runs with the standalone Node.js binary copied from ThingsBoard's prepared `target/node/node`. Run `runtime/node --test tests/*.test.js` without running `npm install`. VS Code should open the whole `user-management` folder; recommended extensions (Java, Python, ESLint, Git) must be staged as `.vsix` on the connected laptop. TypeScript, Prisma, KafkaJS, Jest, etc. are **not** included in this starter and need separately prepared offline package caches when adopted.

### Release completion criteria

- Target laptop never contacts internet during installation or smoke tests.
- Node UI login + local user create/disable works.
- EMQX dashboard loads; MQTT round-trip returns PASS.
- Kafka CLI produce/consume returns PASS.
- ThingsBoard dashboard loads, administrator login succeeds, PostgreSQL is available.
- SHA256 verification passes for all relevant files on the destination.
- VS Code RPM installs and opens source on the offline laptop.

## K. System screenshots / proof

An actual confirmed ThingsBoard 4.3.1.8 System Administrator screenshot from the preparation computer is included as [`reference-thingsboard-running.png`](reference-thingsboard-running.png). It proves that instance's UI was running but **does not verify the new laptop**. Collect fresh screenshots of EMQX Dashboard, Kafka test output, ThingsBoard login, and the Node.js Overview/Users/Integrations pages during the final offline validation.
