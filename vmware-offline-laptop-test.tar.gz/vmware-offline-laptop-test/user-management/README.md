# Offline IoT User Management Starter (Node.js 22)

A **working, zero-npm-dependency**, offline-first Node.js user-management API and responsive browser UI. Intended for a second **openSUSE Leap 15.6** laptop with your already prepared EMQX 5.8.9 / Apache Kafka / ThingsBoard CE 4.3.1.8 / PostgreSQL 16 artifacts.

## Quick start: first laptop (with your existing offline repository)

1. Extract this project ZIP on your preparation machine. Then stage it **inside the offline repository**:

```bash
ROOT=/opt/iot-offline-opensuse15.6
cd /path/to/offline-iot-user-management
bash scripts/stage-on-preparation-machine.sh
```

2. Start the UI using the copied Node binary:

```bash
cd "$ROOT/repos/05-nodejs-pnpm/user-management"
cp .env.example .env
chmod 600 .env
vi .env  # set a unique 12+ character ADMIN_PASSWORD
bash scripts/start-node-offline.sh
```

3. Open **http://127.0.0.1:3000** and log in as the email and password in `.env`. **Change/remove `ADMIN_PASSWORD` from `.env` after bootstrap**; the scrypt-hashed user survives restarts in `~/.local/state/offline-iot-user-management/users.json`.

4. Test from another terminal:

```bash
curl -s http://127.0.0.1:3000/api/health
bash scripts/audit-offline-stack.sh
bash scripts/kafka-smoke.sh  # only after Kafka broker is running
```

5. After staging and downloading the official VS Code RPM, **regenerate** `offline-release/repositories.sha256`, review secret files and run your previously prepared release archiver. The existing full manifest was built before this Node project was added.

## Second laptop: recommended start order

`PostgreSQL → Kafka KRaft → EMQX → ThingsBoard → Node.js User Management UI`

Run **one time only** (brand-new Kafka data directory):

```bash
ROOT=/opt/iot-offline-opensuse15.6
APP="$ROOT/repos/05-nodejs-pnpm/user-management"
bash "$APP/scripts/check-offline-files.sh"
bash "$APP/scripts/start-kafka-offline.sh" --initialize
```

In a separate terminal (after Kafka is running):

```bash
bash "$APP/scripts/start-emqx-offline.sh"
```

Then ensure PostgreSQL and ThingsBoard have already been installed and their database initialized; start their services normally. Start the Node UI in another terminal with `bash "$APP/scripts/start-node-offline.sh"`.

Later starts can use `bash "$APP/scripts/start-local-stack.sh"`, which checks installation status and starts existing services. **It will not format Kafka or initialize PostgreSQL**.

For all steps, troubleshooting and a table of test cases see [docs/OFFLINE-SECOND-LAPTOP.md](docs/OFFLINE-SECOND-LAPTOP.md).

## Functional scope — be precise

| Feature | Included? |
|---|---|
| Responsive browser login + local user CRUD and roles | **YES**, local JSON/scrypt user store |
| No npm install, no third-party packages required for the Node UI | **YES** |
| Service TCP/HTTP status probes | **YES** |
| EMQX MQTT 3.1.1 connect/subscribe/publish/receive round-trip | **YES** (configured broker required) |
| Kafka API check from browser | **YES**, when `KAFKA_TOPICS_BIN` is set |
| Kafka producer/consumer test | **YES**, shell script and UI button, broker required |
| ThingsBoard REST login verification | **YES**, optional configured credentials |
| Automatic user provisioning into ThingsBoard or EMQX | **NO**, future integration |
| Kafka-backed user-management event bus | **NO**, planned enhancement |
| Real-time MQTT sensor bridge | **NO** — this is a User Management System, not a bridge |
| EMQX/Kafka binary packages | **NO**, they must already be in your prepared 19 GB repository |
| Official VS Code RPM | **NO**, download on connected laptop and transfer |

### Security and deployment limits

**Development prototype only.** Web API binds `127.0.0.1` by default. Passwords are hashed with Node's `scrypt`, sessions are short-lived and HttpOnly, write requests use CSRF headers. No TLS/reverse proxy, durable sessions, centralized secrets vault, enterprise RBAC, or automatic external identity federation is bundled. Never publish `.env`, `~/.local/state/offline-iot-user-management/users.json`, or the actual second laptop's credential backups to GitHub.

## Developer setup in offline VS Code

Download the official VS Code x64 RPM and any VSIX extensions on your connected machine (the earlier release toolkit contains download scripts). Store them inside the 19 GB release tree, then use `bash scripts/install-vscode-offline.sh` on the second laptop, after the other system dependencies are met. Open this folder using `code .`. A preconfigured `.vscode/launch.json` uses the staged `runtime/node` and `.env` for debugging. The login UI is at `http://127.0.0.1:3000`.
