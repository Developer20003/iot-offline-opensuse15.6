#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="${ROOT:-/opt/iot-offline-opensuse15.6}"
echo '=== OFFLINE BUNDLE PREREQUISITES ==='
check(){if [[ -e "$2" ]]; then echo "OK   $1: $2";else echo "MISS $1: $2";fi;}
check 'ThingsBoard RPM' "$ROOT/repos/04-thingsboard/source/thingsboard/application/target/thingsboard.rpm"
check 'Node.js 22 binary' "$ROOT/repos/04-thingsboard/source/thingsboard/msa/web-ui/target/node/node"
check 'EMQX source-built release' "$ROOT/repos/02-erlang-emqx/source/emqx/_build/emqx/rel/emqx/bin/emqx"
check 'User Management app' "$ROOT/repos/05-nodejs-pnpm/user-management/package.json"
check 'Gradle 7.3.3' "$ROOT/repos/04-thingsboard/gradle-distribution/gradle-7.3.3/bin/gradle"
check 'Maven cache' "$ROOT/repos/04-thingsboard/maven-repo"
check 'Yarn cache' "$ROOT/repos/04-thingsboard/yarn-cache"
check 'Manifest' "$ROOT/offline-release/repositories.sha256"
echo '=== KAFKA START SCRIPT ==='
find "$ROOT/repos/03-java-kafka" -type f -name kafka-server-start.sh -print -quit
printf '\n=== VS CODE RPM ===\n'
find "$ROOT/repos" -type f -name 'code-*.rpm' -print -quit
printf '\n=== PLATFORM ===\n'
uname -m
