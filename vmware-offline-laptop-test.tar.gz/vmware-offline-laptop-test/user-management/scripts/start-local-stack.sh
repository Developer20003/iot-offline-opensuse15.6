#!/usr/bin/env bash
# Convenience startup of pre-installed local services. It does NOT install RPMs or format Kafka.
set -u
ROOT="${ROOT:-/opt/iot-offline-opensuse15.6}"
APP="$ROOT/repos/05-nodejs-pnpm/user-management"
RUN="$ROOT/runtime"
mkdir -p "$RUN/logs" "$RUN/pids"
echo '=== Starting existing PostgreSQL / ThingsBoard services (when installed) ==='
for service in postgresql thingsboard; do
  if systemctl list-unit-files "$service.service" --no-legend 2>/dev/null | grep -q "^$service.service";then
    if systemctl is-active --quiet "$service"; then echo "$service already running";
    elif [[ $EUID -eq 0 ]]; then systemctl start "$service" && echo "$service started" || echo "$service failed (inspect journalctl -u $service)";
    else echo "Start $service as root: sudo systemctl start $service";fi
  else echo "$service not installed; skipping";fi
done
echo '=== Starting EMQX (if not already on MQTT port) ==='
if ss -ltn | grep -q ':1883 ';then echo 'MQTT 1883 already listening; check owner (could be ThingsBoard, not EMQX).';
else bash "$APP/scripts/start-emqx-offline.sh" || echo 'EMQX start failed; see errors above';fi
echo '=== Starting Kafka when already initialized ==='
if ss -ltn | grep -q ':9092 ';then echo 'Kafka 9092 already listening';
else
  if [[ ! -f "$RUN/kafka/kraft-logs/meta.properties" ]];then
    echo "Kafka not initialized by this toolkit. For NEW cluster, run: bash $APP/scripts/start-kafka-offline.sh --initialize"
    echo 'Use a second terminal; do not initialize an existing cluster.'
  else
    nohup bash "$APP/scripts/start-kafka-offline.sh" > "$RUN/logs/kafka-console.log" 2>&1 < /dev/null &
    echo "$!" > "$RUN/pids/kafka.pid"
    echo "Kafka startup requested; log: $RUN/logs/kafka-console.log"
  fi
fi
echo '=== Starting Node.js management UI ==='
if [[ ! -f "$APP/.env" ]];then echo "Missing $APP/.env (copy .env.example, set ADMIN_PASSWORD)";
else
  nohup bash "$APP/scripts/start-node-offline.sh" > "$RUN/logs/user-management.log" 2>&1 < /dev/null &
  echo "$!" > "$RUN/pids/user-management.pid"
  echo "Node startup requested; log: $RUN/logs/user-management.log"
fi
echo '=== Services and ports ==='
bash "$APP/scripts/audit-offline-stack.sh" || true
