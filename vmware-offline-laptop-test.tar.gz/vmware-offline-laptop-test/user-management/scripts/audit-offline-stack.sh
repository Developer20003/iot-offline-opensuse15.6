#!/usr/bin/env bash
set -u
ROOT="${ROOT:-/opt/iot-offline-opensuse15.6}"
echo '=== OS AND DATE ==='; sed -n '1,8p' /etc/os-release; date -Is
echo '=== RPM INVENTORY ==='; find "$ROOT/repos" -type f -name '*.rpm' | wc -l
echo '=== RUNNING SERVICES ==='; for s in thingsboard postgresql emqx kafka docker; do printf '%-14s' "$s";systemctl is-active "$s" 2>/dev/null || true;done
echo '=== LISTENING PORTS ==='; ss -ltnp | grep -E ':(3000|5432|8080|1883|18083|9092|9093)[[:space:]]' || true
echo '=== HTTP ===';for url in http://127.0.0.1:3000/api/health http://127.0.0.1:18083 http://127.0.0.1:8080/login; do printf '%-51s ' "$url";curl -sS -m 3 -o /dev/null -w 'HTTP %{http_code}\n' "$url" || true;done
echo '=== KAFKA BINARY ===';find "$ROOT/repos/03-java-kafka" -type f -name kafka-server-start.sh -print -quit
echo '=== EMQX BINARY ===';find "$ROOT/repos/02-erlang-emqx" -type f -path '*/rel/emqx/bin/emqx' -print -quit
echo '=== NODE ===';if [[ -x "$ROOT/repos/05-nodejs-pnpm/user-management/runtime/node" ]]; then "$ROOT/repos/05-nodejs-pnpm/user-management/runtime/node" --version;fi
