#!/usr/bin/env bash
# Verified end-to-end Kafka CLI test: create an isolated topic, publish, consume and compare.
set -Eeuo pipefail
ROOT="${ROOT:-/opt/iot-offline-opensuse15.6}"
DIR="$ROOT/repos/03-java-kafka"
SERVER="$(find "$DIR" -type f -path '*/bin/kafka-topics.sh' -print -quit)"
[[ -n "$SERVER" ]] || { echo "Kafka CLI not found under $DIR" >&2; exit 2; }
BIN="$(cd "$(dirname "$SERVER")" && pwd)"
BROKER="${KAFKA_BOOTSTRAP:-127.0.0.1:9092}"
TOPIC="ums.smoke.$(date +%s).$$"
MARKER="offline-user-management-smoke-$(date +%s)-$$"
echo "Creating test topic: $TOPIC"
"$BIN/kafka-topics.sh" --bootstrap-server "$BROKER" --create --topic "$TOPIC" --partitions 1 --replication-factor 1
printf '%s\n' "$MARKER" | "$BIN/kafka-console-producer.sh" --bootstrap-server "$BROKER" --topic "$TOPIC"
echo 'Consuming one message:'
RECEIVED="$("$BIN/kafka-console-consumer.sh" --bootstrap-server "$BROKER" --topic "$TOPIC" --from-beginning --max-messages 1 --timeout-ms 10000)"
if [[ "$RECEIVED" == "$MARKER" ]]; then
  echo "PASS: Kafka round-trip marker = $MARKER"
else
  echo "FAIL: Expected [$MARKER], received [$RECEIVED]" >&2
  exit 1
fi
"$BIN/kafka-topics.sh" --bootstrap-server "$BROKER" --delete --topic "$TOPIC" || true
