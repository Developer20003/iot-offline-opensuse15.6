#!/usr/bin/env bash
# Kafka 3.x/4.x local KRaft startup. Explicit --initialize only for a genuinely new data directory.
# Does not download, reformat or delete an existing cluster.
set -Eeuo pipefail
ROOT="${ROOT:-/opt/iot-offline-opensuse15.6}"
DIR="$ROOT/repos/03-java-kafka"
RUNTIME="$ROOT/runtime/kafka"
BIN="${KAFKA_HOME:-}"
if [[ -z "$BIN" ]]; then
  SERVER="$(find "$DIR" -type f -path '*/bin/kafka-server-start.sh' -print -quit)"
  [[ -n "$SERVER" ]] || { echo "Cannot find kafka-server-start.sh under $DIR" >&2; exit 2; }
  BIN="$(cd "$(dirname "$SERVER")/.." && pwd)"
fi
[[ -x "$BIN/bin/kafka-storage.sh" ]] || { echo "Kafka storage CLI missing under $BIN/bin" >&2; exit 2; }
TEMPLATE="$BIN/config/kraft/server.properties"
if [[ ! -f "$TEMPLATE" ]]; then TEMPLATE="$BIN/config/server.properties"; fi
[[ -f "$TEMPLATE" ]] || { echo "No KRaft server.properties under $BIN/config" >&2; exit 2; }
mkdir -p "$RUNTIME" "$RUNTIME/kraft-logs"
CFG="$RUNTIME/server.properties"
if [[ ! -f "$CFG" ]]; then
  python3 - "$TEMPLATE" "$CFG" "$RUNTIME/kraft-logs" <<'PY'
import sys
src,dst,logs=sys.argv[1:]
with open(src) as f: lines=f.readlines()
replacements={
 'log.dirs':logs,
 'listeners':'PLAINTEXT://127.0.0.1:9092,CONTROLLER://127.0.0.1:9093',
 'advertised.listeners':'PLAINTEXT://127.0.0.1:9092',
 'process.roles':'broker,controller',
 'node.id':'1',
 'controller.listener.names':'CONTROLLER',
 'listener.security.protocol.map':'CONTROLLER:PLAINTEXT,PLAINTEXT:PLAINTEXT',
 'inter.broker.listener.name':'PLAINTEXT',
}
seen=set();out=[]
for line in lines:
  stripped=line.strip()
  if not stripped.startswith('#') and '=' in stripped:
    key=stripped.split('=',1)[0].strip()
    if key in replacements:line=key+'='+replacements[key]+'\n';seen.add(key)
  out.append(line)
for key,value in replacements.items():
  if key not in seen:out.append(key+'='+value+'\n')
with open(dst,'x') as f:f.writelines(out)
print('Created persistent config:',dst)
PY
fi
if [[ ! -f "$RUNTIME/kraft-logs/meta.properties" ]]; then
  if [[ "${1:-}" != '--initialize' ]]; then
    echo "UNFORMATTED KRaft directory: $RUNTIME/kraft-logs" >&2
    echo "If this is a NEW Kafka cluster, run: bash $0 --initialize" >&2
    echo 'If you have old Kafka data, locate its real log.dirs instead; do NOT format it.' >&2
    exit 3
  fi
  echo 'Initializing NEW local KRaft cluster.'
  ID="$("$BIN/bin/kafka-storage.sh" random-uuid)"
  if grep -qE '^controller.quorum.bootstrap.servers=' "$CFG"; then
    "$BIN/bin/kafka-storage.sh" format --standalone -t "$ID" -c "$CFG"
  else
    "$BIN/bin/kafka-storage.sh" format -t "$ID" -c "$CFG"
  fi
fi
if ss -ltn | grep -Eq '(:|\.)9092[[:space:]]'; then
  echo 'Port 9092 already occupied. Stop and inspect with: ss -ltnp | grep :9092' >&2
  exit 4
fi
export KAFKA_HEAP_OPTS="${KAFKA_HEAP_OPTS:--Xms512m -Xmx1g}"
echo "Starting Kafka from $BIN with $CFG"
echo 'This command runs in the FOREGROUND; use a separate terminal for Node.js.'
exec "$BIN/bin/kafka-server-start.sh" "$CFG"
