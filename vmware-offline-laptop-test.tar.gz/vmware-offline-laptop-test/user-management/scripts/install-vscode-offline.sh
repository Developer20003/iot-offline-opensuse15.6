#!/usr/bin/env bash
# Installs a PRE-DOWNLOADED official VS Code RPM. Never opens a network repository.
set -Eeuo pipefail
ROOT="${ROOT:-/opt/iot-offline-opensuse15.6}"
RPM_FILE="${1:-}"
if [[ -z "$RPM_FILE" ]];then
  RPM_FILE="$(find "$ROOT/repos" -type f -name 'code-*.rpm' -print -quit)"
fi
if [[ -z "$RPM_FILE" || ! -f "$RPM_FILE" ]];then
  echo "VS Code RPM missing. Download official Linux x64 RPM on the connected computer and save under $ROOT/repos/08-vscode/rpms/." >&2
  exit 2
fi
if [[ $EUID -ne 0 ]];then
  echo 'Run as root to install the RPM after checking dependencies.' >&2
  exit 2
fi
echo "Offline RPM dependency test: $RPM_FILE"
rpm -Uvh --test "$RPM_FILE"
echo "Installing the local RPM: $RPM_FILE"
rpm -Uvh "$RPM_FILE"
code --version
