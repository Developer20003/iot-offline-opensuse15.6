#!/usr/bin/env bash
# Copy this starter into the preexisting 19 GB offline repository. Idempotent, no deletes.
set -Eeuo pipefail
ROOT="${ROOT:-/opt/iot-offline-opensuse15.6}"
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DEST="$ROOT/repos/05-nodejs-pnpm/user-management"
NODE_SOURCE="$ROOT/repos/04-thingsboard/source/thingsboard/msa/web-ui/target/node/node"
[[ -f "$SRC/package.json" ]] || { echo 'Cannot locate project root'; exit 1; }
[[ -x "$NODE_SOURCE" ]] || { echo "Missing Node 22: $NODE_SOURCE"; exit 1; }
if [[ -e "$DEST/package.json" ]]; then
  echo "Already staged: $DEST"; echo 'No files overwritten. Review and update manually as needed.'
else
  mkdir -p "$DEST"
  (cd "$SRC" && tar -cf - --exclude=./.env --exclude=./data/users.json --exclude=./runtime/node --exclude=./node_modules .) | (cd "$DEST" && tar -xf -)
  echo "Project staged: $DEST"
fi
mkdir -p "$DEST/runtime" "$DEST/data"
if [[ ! -e "$DEST/runtime/node" ]]; then
  cp "$NODE_SOURCE" "$DEST/runtime/node"
  chmod 755 "$DEST/runtime/node"
fi
"$DEST/runtime/node" --version
printf '\nNEXT (on either laptop):\n  cd %s\n  cp .env.example .env\n  chmod 600 .env\n  vi .env   # set ADMIN_PASSWORD, keep HOST=127.0.0.1\n  bash scripts/start-node-offline.sh\n' "$DEST"
echo 'If you have already generated repositories.sha256, regenerate it AFTER staging this project.'
