#!/usr/bin/env bash
# Read-only checks before merging the project into a public / shared offline release.
set -u
ROOT="${ROOT:-/opt/iot-offline-opensuse15.6}"
APP="$ROOT/repos/05-nodejs-pnpm/user-management"
FAIL=0
echo '=== OFFLINE NODE PROJECT ==='
if [[ -f "$APP/package.json" ]];then echo 'OK: source staged';else echo 'MISSING: source project';FAIL=1;fi
if [[ -x "$APP/runtime/node" ]];then "$APP/runtime/node" --version;else echo 'MISSING: standalone Node runtime';FAIL=1;fi
echo '=== SENSITIVE FILES IN THE STAGED PROJECT ==='
for file in "$APP/.env" "$APP/data/users.json"; do
  if [[ -e "$file" ]];then echo "WARNING: remove from the release before packing: $file";FAIL=1;fi
done
echo '=== EMQX / KAFKA INSTALL ARTIFACTS ==='
if [[ -x "$ROOT/repos/02-erlang-emqx/source/emqx/_build/emqx/rel/emqx/bin/emqx" ]];then echo 'OK: EMQX compiled release exists';else echo 'MISSING: EMQX compiled release';FAIL=1;fi
if find "$ROOT/repos/03-java-kafka" -type f -name kafka-server-start.sh -print -quit | grep -q .;then echo 'OK: Kafka launcher exists';else echo 'MISSING: Kafka extracted distribution';FAIL=1;fi
printf '=== RELEASE PREFLIGHT STATUS: %s ===\n' "$([[ $FAIL == 0 ]] && echo 'PASS (not full runtime test)' || echo 'INCOMPLETE')"
exit "$FAIL"
