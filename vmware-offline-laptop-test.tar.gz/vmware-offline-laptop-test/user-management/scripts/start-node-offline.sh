#!/usr/bin/env bash
# Run from any directory. No npm install, npm registry or Internet is used.
set -Eeuo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ROOT="${ROOT:-/opt/iot-offline-opensuse15.6}"
NODE="$DIR/runtime/node"
if [[ ! -x "$NODE" ]]; then
  NODE="$ROOT/repos/04-thingsboard/source/thingsboard/msa/web-ui/target/node/node"
fi
if [[ ! -x "$NODE" ]]; then
  echo 'ERROR: Node binary absent. Run scripts/stage-on-preparation-machine.sh BEFORE transfer.' >&2
  exit 2
fi
if [[ ! -f "$DIR/.env" ]]; then
  cp "$DIR/.env.example" "$DIR/.env"
  chmod 600 "$DIR/.env"
  echo "Created $DIR/.env; edit ADMIN_PASSWORD before launching." >&2
  exit 3
fi
exec "$NODE" "$DIR/src/server.js"
