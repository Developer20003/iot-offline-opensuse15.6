#!/usr/bin/env bash
# EMQX 5.8.9 CE: only start an existing installed service or pre-built source release.
set -Eeuo pipefail
ROOT="${ROOT:-/opt/iot-offline-opensuse15.6}"
if systemctl list-unit-files emqx.service --no-legend 2>/dev/null | grep -q '^emqx.service'; then
  echo 'Using installed EMQX systemd unit.'
  sudo_cmd=(); [[ $EUID -eq 0 ]] || sudo_cmd=(sudo)
  "${sudo_cmd[@]}" systemctl start emqx
  "${sudo_cmd[@]}" systemctl status emqx --no-pager -l
  exit 0
fi
BASE="$ROOT/repos/02-erlang-emqx/source/emqx/_build/emqx/rel/emqx"
if [[ ! -x "$BASE/bin/emqx" ]]; then
  echo "EMQX pre-built release not found: $BASE/bin/emqx" >&2
  echo 'The source repository alone is insufficient; you must transfer the compiled release and runtime dependencies.' >&2
  exit 2
fi
if ss -ltn | grep -Eq '(:|\.)1883[[:space:]]'; then
  echo 'Port 1883 is already listening. Check: ss -ltnp | grep :1883' >&2
  echo 'Do not start a second broker or overwrite ThingsBoard MQTT listener settings.' >&2
  exit 3
fi
cd "$BASE"
./bin/emqx start
./bin/emqx ctl status || true
echo 'EMQX dashboard: http://127.0.0.1:18083 (change the default password).'
