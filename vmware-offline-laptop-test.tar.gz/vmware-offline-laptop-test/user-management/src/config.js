'use strict';
const fs = require('node:fs');
const path = require('node:path');
const ROOT = path.resolve(__dirname, '..');
function parseEnv(text) {
  const out = {};
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const m = line.match(/^(?:export\s+)?([A-Z][A-Z0-9_]*)=(.*)$/);
    if (!m) continue;
    let value = m[2].trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    out[m[1]] = value;
  }
  return out;
}
const fromFile = fs.existsSync(path.join(ROOT, '.env')) ? parseEnv(fs.readFileSync(path.join(ROOT, '.env'), 'utf8')) : {};
const get = (k, def = '') => process.env[k] !== undefined ? process.env[k] : (fromFile[k] !== undefined ? fromFile[k] : def);
const num = (k, def) => { const n = Number(get(k, def)); return Number.isInteger(n) && n > 0 && n <= 65535 ? n : def; };
module.exports = {
  ROOT, get, parseEnv,
  host: get('HOST','127.0.0.1'), port: num('PORT',3000),
  adminEmail: get('ADMIN_EMAIL','admin@local.test').toLowerCase(),
  adminPassword: get('ADMIN_PASSWORD',''),
  emqxHost: get('EMQX_HOST','127.0.0.1'), emqxPort: num('EMQX_PORT',1883),
  emqxDashboard: get('EMQX_DASHBOARD_URL','http://127.0.0.1:18083'),
  mqttUser: get('MQTT_USERNAME'), mqttPassword: get('MQTT_PASSWORD'),
  kafkaHost: get('KAFKA_HOST','127.0.0.1'), kafkaPort: num('KAFKA_PORT',9092), kafkaTopicsBin: get('KAFKA_TOPICS_BIN'),
  tbUrl: get('TB_URL','http://127.0.0.1:8080'), tbUser: get('TB_USERNAME'), tbPassword: get('TB_PASSWORD'),
  pgHost: get('PG_HOST','127.0.0.1'), pgPort: num('PG_PORT',5432)
};
