'use strict';
const net = require('node:net');
function port(host,number, timeout=1500) {
  return new Promise(resolve=>{
    const sock=net.connect({host,port:number});
    let done=false;
    const finish=(ok,detail)=>{if(done)return;done=true;sock.destroy();resolve({ok,detail});};
    sock.setTimeout(timeout);
    sock.once('connect',()=>finish(true,'TCP port is open (not an application-level check)'));
    sock.once('error',e=>finish(false,e.code||e.message));
    sock.once('timeout',()=>finish(false,'Connection timeout'));
  });
}
async function httpGet(url, timeout=2500) {
  try{
    const res=await fetch(url,{redirect:'manual',signal:AbortSignal.timeout(timeout)});
    return {ok:res.status>=200&&res.status<500,detail:`HTTP ${res.status}`,code:res.status};
  }catch(e){return {ok:false,detail:e.cause?.code||e.message};}
}
module.exports={port,httpGet};
