'use strict';
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { get } = require('./config');
// Persist user credentials OUTSIDE the transferable source repository.
const DATA_DIR = get('USER_DATA_DIR') || path.join(os.homedir(), '.local', 'state', 'offline-iot-user-management');
const FILE = path.join(DATA_DIR, 'users.json');
const emailOk = (s) => typeof s === 'string' && s.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);
const allowedRoles = ['admin','operator','viewer'];
function digest(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(password, Buffer.from(salt, 'hex'), 64).toString('hex');
  return `${salt}:${hash}`;
}
function verify(password, encoded) {
  if (typeof encoded !== 'string') return false;
  const [salt, hex] = encoded.split(':');
  if (!salt || !hex || !/^[a-f0-9]+$/i.test(salt) || !/^[a-f0-9]+$/i.test(hex)) return false;
  const actual = Buffer.from(digest(password,salt).split(':')[1],'hex');
  const expected = Buffer.from(hex,'hex');
  return actual.length === expected.length && crypto.timingSafeEqual(actual,expected);
}
class Store {
  constructor(file = FILE) {
    this.file = file;
    fs.mkdirSync(path.dirname(file),{recursive:true,mode:0o700});
    this.records = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file,'utf8')) : [];
    if (!Array.isArray(this.records)) throw new Error('Invalid users database');
  }
  save() {
    const temp = `${this.file}.tmp-${process.pid}`;
    fs.writeFileSync(temp, JSON.stringify(this.records,null,2)+'\n',{mode:0o600});
    fs.chmodSync(temp,0o600);
    fs.renameSync(temp,this.file);
  }
  bootstrap(email,password) {
    if (this.records.length) return false;
    if (!emailOk(email) || !password || password.length < 12 || password === 'REPLACE_WITH_A_LONG_UNIQUE_PASSWORD') {
      throw new Error('Set a valid ADMIN_EMAIL and ADMIN_PASSWORD (at least 12 chars) in .env before first launch');
    }
    this.records.push({id:crypto.randomUUID(),email:email.toLowerCase(),name:'Local Administrator',role:'admin',active:true,hash:digest(password),createdAt:new Date().toISOString()});
    this.save(); return true;
  }
  publicUser(u) { const {hash,...clean} = u; return clean; }
  list() {return this.records.map(u=>this.publicUser(u));}
  byId(id) {return this.records.find(u=>u.id===id);}
  authenticate(email,password) { const u=this.records.find(x=>x.email===String(email).toLowerCase() && x.active);return u && verify(String(password),u.hash) ? u : null; }
  create(data) {
    const email = String(data.email || '').trim().toLowerCase();
    const name = String(data.name || '').trim();
    const password = String(data.password || '');
    const role = String(data.role || 'viewer');
    if (!emailOk(email)) throw new Error('Valid email required');
    if (!name || name.length>100) throw new Error('Name must be 1–100 characters');
    if (!allowedRoles.includes(role)) throw new Error('Invalid role');
    if (password.length<12) throw new Error('Password must be at least 12 characters');
    if (this.records.some(u=>u.email===email)) throw new Error('Email already exists');
    const u={id:crypto.randomUUID(),email,name,role,active:true,hash:digest(password),createdAt:new Date().toISOString()};
    this.records.push(u);this.save();return this.publicUser(u);
  }
  edit(id,data,actorId) {
    const u=this.byId(id);if(!u)throw new Error('User not found');
    if ('name' in data){const name=String(data.name||'').trim();if(!name||name.length>100)throw new Error('Invalid name');u.name=name;}
    if ('role' in data){if(!allowedRoles.includes(data.role))throw new Error('Invalid role');if(u.id===actorId&&data.role!=='admin')throw new Error('Cannot demote your own admin account');u.role=data.role;}
    if ('active' in data){if(typeof data.active!=='boolean')throw new Error('active must be boolean');if(u.id===actorId&&!data.active)throw new Error('Cannot disable your own account');u.active=data.active;}
    if ('password' in data){if(String(data.password).length<12)throw new Error('Password must be at least 12 characters');u.hash=digest(String(data.password));}
    this.save();return this.publicUser(u);
  }
  disable(id,actorId) {if(id===actorId)throw new Error('Cannot disable your own account');return this.edit(id,{active:false},actorId);}
}
module.exports={Store,digest,verify,emailOk,allowedRoles};
