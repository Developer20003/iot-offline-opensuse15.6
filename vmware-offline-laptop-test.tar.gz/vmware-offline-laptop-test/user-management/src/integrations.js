'use strict';
const {execFile}=require('node:child_process');
const fs=require('node:fs');
const path=require('node:path');
const {ROOT,get,emqxDashboard,tbUrl,tbUser,tbPassword,kafkaTopicsBin,kafkaHost,kafkaPort}=require('./config');
async function emqxApiTest(){
  const key=get('EMQX_API_KEY'),secret=get('EMQX_API_SECRET');
  if(!key||!secret)return {ok:false,detail:'Set EMQX_API_KEY and EMQX_API_SECRET in .env to test management API',configured:false};
  try{
    const res=await fetch(new URL('/api/v5/nodes',emqxDashboard),{headers:{Authorization:'Basic '+Buffer.from(key+':'+secret).toString('base64')},signal:AbortSignal.timeout(4000)});
    const text=(await res.text()).slice(0,300);
    return {ok:res.ok,detail:res.ok?'EMQX management API authenticated':`EMQX API HTTP ${res.status}: ${text}`};
  }catch(e){return {ok:false,detail:e.message};}
}
async function thingsboardApiTest(){
  if(!tbUser||!tbPassword)return {ok:false,detail:'Optional: set TB_USERNAME and TB_PASSWORD in .env to verify REST login',configured:false};
  try{
    const res=await fetch(new URL('/api/auth/login',tbUrl),{
      method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:tbUser,password:tbPassword}),signal:AbortSignal.timeout(6000)
    });
    if(!res.ok)return {ok:false,detail:`ThingsBoard auth HTTP ${res.status}`};
    const obj=await res.json();
    return {ok:!!obj.token,detail:obj.token?'ThingsBoard REST login successful':'No token in response'};
  }catch(e){return {ok:false,detail:e.message};}
}
function kafkaCliTest(){
  return new Promise(resolve=>{
    if(!kafkaTopicsBin||!fs.existsSync(kafkaTopicsBin))return resolve({ok:false,detail:'Set KAFKA_TOPICS_BIN to the installed kafka-topics.sh path for protocol-level Kafka verification',configured:false});
    execFile(kafkaTopicsBin,['--bootstrap-server',`${kafkaHost}:${kafkaPort}`,'--list'],{timeout:12000,maxBuffer:512*1024,env:{...process.env,JMX_PORT:''}},(error,stdout,stderr)=>{
      if(error)return resolve({ok:false,detail:(stderr||error.message).slice(0,500)});
      const topics=stdout.trim().split('\n').filter(Boolean);
      resolve({ok:true,detail:`Kafka admin API returned ${topics.length} topic(s)`,topics:topics.slice(0,20)});
    });
  });
}
function kafkaRoundTripTest(){
  return new Promise(resolve=>{
    const script=path.join(ROOT,'scripts','kafka-smoke.sh');
    if(!fs.existsSync(script))return resolve({ok:false,detail:'Kafka smoke test script missing'});
    execFile('/bin/bash',[script],{timeout:45000,maxBuffer:1024*1024,env:{...process.env,KAFKA_BOOTSTRAP:`${kafkaHost}:${kafkaPort}`}},(error,stdout,stderr)=>{
      const output=(stdout+'\n'+stderr).slice(-1300);
      if(error)return resolve({ok:false,detail:'Kafka produce/consume failed: '+output});
      resolve({ok:stdout.includes('PASS: Kafka round-trip'),detail:output.trim()});
    });
  });
}
module.exports={emqxApiTest,thingsboardApiTest,kafkaCliTest,kafkaRoundTripTest};
