'use strict';
const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const cfg=require('./config');
const {Store}=require('./storage');
const {port,httpGet}=require('./probes');
const {mqttSmoke}=require('./mqtt');
const {emqxApiTest,thingsboardApiTest,kafkaCliTest,kafkaRoundTripTest}=require('./integrations');
const store=new Store();
const bootstrap=store.bootstrap(cfg.adminEmail,cfg.adminPassword);
if(bootstrap)console.log('Created local admin:',cfg.adminEmail);
const sessions=new Map();
const loginFails=new Map();
const staticFiles={'/':'index.html','/index.html':'index.html','/app.js':'app.js','/app.css':'app.css'};
function reply(res,code,obj){const text=JSON.stringify(obj);res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(text);}
function cookie(req){const found=(req.headers.cookie||'').match(/(?:^|;\s*)ums_session=([^;]+)/);return found?.[1]||'';}
function getSession(req){const id=cookie(req),s=sessions.get(id);if(!s)return null;if(s.expires<Date.now()){sessions.delete(id);return null;}const u=store.byId(s.uid);if(!u?.active){sessions.delete(id);return null;}return {id,token:s.csrf,user:u};}
function body(req){return new Promise((resolve,reject)=>{let chunks=[],size=0;req.on('data',b=>{size+=b.length;if(size>65536){reject(new Error('Request too large'));req.destroy();}else chunks.push(b);});req.on('end',()=>{try{resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')||'{}'));}catch{reject(new Error('Malformed JSON'));}});req.on('error',reject);});}
async function processRequest(req,res){
  const url=new URL(req.url,'http://local');const endpoint=url.pathname;
  res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Frame-Options','DENY');res.setHeader('Content-Security-Policy',"default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'; base-uri 'none'; object-src 'none'; frame-ancestors 'none'");
  if(req.method==='GET'&&staticFiles[endpoint]){
    const name=staticFiles[endpoint];const type=name.endsWith('.js')?'text/javascript':name.endsWith('.css')?'text/css':'text/html';
    res.writeHead(200,{'Content-Type':type+'; charset=utf-8','Cache-Control':'no-store'});
    return fs.createReadStream(path.join(cfg.ROOT,'public',name)).pipe(res);
  }
  if(!endpoint.startsWith('/api/'))return reply(res,404,{error:'Not found'});
  if(endpoint==='/api/health'&&req.method==='GET')return reply(res,200,{ok:true,service:'offline-iot-user-management',uptimeSeconds:Math.floor(process.uptime())});
  if(endpoint==='/api/login'&&req.method==='POST'){
    const ip=req.socket.remoteAddress||'local';const record=loginFails.get(ip)||{count:0,until:0};
    if(record.until>Date.now())return reply(res,429,{error:'Too many login attempts; retry after 60 seconds'});
    const data=await body(req),u=store.authenticate(data.email,data.password);
    if(!u){record.count++;if(record.count>=5){record.until=Date.now()+60000;record.count=0;}loginFails.set(ip,record);return reply(res,401,{error:'Invalid email or password'});}
    loginFails.delete(ip);
    const id=crypto.randomBytes(32).toString('hex');const csrf=crypto.randomBytes(32).toString('hex');sessions.set(id,{uid:u.id,csrf,expires:Date.now()+8*3600*1000});
    res.setHeader('Set-Cookie',`ums_session=${id}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800`);
    return reply(res,200,{user:store.publicUser(u),csrf});
  }
  const session=getSession(req);
  if(endpoint==='/api/session'&&req.method==='GET')return reply(res,200,session?{authenticated:true,user:store.publicUser(session.user),csrf:session.token}:{authenticated:false});
  if(!session)return reply(res,401,{error:'Login required'});
  if(!['GET','HEAD'].includes(req.method)&&req.headers['x-csrf-token']!==session.token)return reply(res,403,{error:'CSRF token missing'});
  if(endpoint==='/api/logout'&&req.method==='POST'){sessions.delete(session.id);res.setHeader('Set-Cookie','ums_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');return reply(res,200,{ok:true});}
  if(endpoint==='/api/users'&&req.method==='GET')return reply(res,200,{users:store.list()});
  if(endpoint==='/api/users'&&req.method==='POST'){
    if(session.user.role!=='admin')return reply(res,403,{error:'Admin required'});
    return reply(res,201,{user:store.create(await body(req))});
  }
  const userId=endpoint.match(/^\/api\/users\/([0-9a-f-]+)$/);
  if(userId&&(req.method==='PATCH'||req.method==='DELETE')){
    if(session.user.role!=='admin')return reply(res,403,{error:'Admin required'});
    const u=req.method==='DELETE'?store.disable(userId[1],session.user.id):store.edit(userId[1],await body(req),session.user.id);
    return reply(res,200,{user:u});
  }
  if(endpoint==='/api/status'&&req.method==='GET'){
    const [emqxMqtt,emqxUi,kafka,tb,postgres]=await Promise.all([
      port(cfg.emqxHost,cfg.emqxPort),httpGet(cfg.emqxDashboard),port(cfg.kafkaHost,cfg.kafkaPort),httpGet(new URL('/login',cfg.tbUrl)),port(cfg.pgHost,cfg.pgPort)
    ]);
    return reply(res,200,{services:{emqxMqtt,emqxUi,kafka,thingsboard:tb,postgres},checkedAt:new Date().toISOString()});
  }
  const tests={'/api/test/mqtt':()=>mqttSmoke({host:cfg.emqxHost,port:cfg.emqxPort,username:cfg.mqttUser,password:cfg.mqttPassword}),
    '/api/test/kafka':kafkaCliTest,'/api/test/kafka-roundtrip':kafkaRoundTripTest,'/api/test/thingsboard':thingsboardApiTest,'/api/test/emqx-api':emqxApiTest};
  if(req.method==='POST'&&tests[endpoint]){
    if(session.user.role!=='admin')return reply(res,403,{error:'Admin required'});
    try{const result=await tests[endpoint]();return reply(res,result.ok?200:422,result);}catch(e){return reply(res,422,{ok:false,detail:e.message});}
  }
  return reply(res,404,{error:'Unknown API endpoint'});
}
const server=http.createServer((req,res)=>{processRequest(req,res).catch(e=>{console.error('Request error:',e.message);if(!res.headersSent)reply(res,400,{error:e.message});else res.end();});});
server.listen(cfg.port,cfg.host,()=>{console.log(`Local UI: http://${cfg.host}:${cfg.port}`);console.log('No npm modules needed. All data stays on this machine.');});
