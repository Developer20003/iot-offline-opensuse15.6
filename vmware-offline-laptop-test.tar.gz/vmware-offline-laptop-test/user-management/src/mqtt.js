'use strict';
// Minimal MQTT 3.1.1 QoS0 PUB/SUB smoke test, zero dependencies.
const net=require('node:net');
const crypto=require('node:crypto');
function encodeLength(n){const out=[];do{let b=n%128;n=Math.floor(n/128);if(n>0)b|=128;out.push(b);}while(n>0);return Buffer.from(out);}
function word(value){const v=Buffer.from(String(value),'utf8');if(v.length>65535)throw new Error('MQTT string too long');const b=Buffer.alloc(2);b.writeUInt16BE(v.length);return Buffer.concat([b,v]);}
function packet(type,payload){return Buffer.concat([Buffer.from([type]),encodeLength(payload.length),payload]);}
function connectPacket(clientId,user,password){
  let flags=2;
  let tail=[word(clientId)];
  if(user){flags|=0x80;tail.push(word(user));}
  if(password){flags|=0x40;tail.push(word(password));}
  const variable=Buffer.concat([word('MQTT'),Buffer.from([4,flags,0,30])]);
  return packet(0x10,Buffer.concat([variable,...tail]));
}
function subscribePacket(topic){return packet(0x82,Buffer.concat([Buffer.from([0,1]),word(topic),Buffer.from([0])]));}
function publishPacket(topic,message){return packet(0x30,Buffer.concat([word(topic),Buffer.from(message)]));}
function extract(buf){if(buf.length<2)return null;let remaining=0,mult=1,i=1,b;do{if(i>=buf.length)return null;b=buf[i++];remaining+=(b&127)*mult;mult*=128;if(i>5)throw new Error('Invalid MQTT remaining length');}while(b&128);if(buf.length<i+remaining)return null;return {type:buf[0]>>4,body:buf.subarray(i,i+remaining),length:i+remaining};}
function mqttSmoke(options){
  const host=options.host||'127.0.0.1',port=options.port||1883,username=options.username||'',password=options.password||'';
  const nonce=crypto.randomBytes(8).toString('hex');
  const topic='lab/ums/smoke/'+nonce;const msg='ums-offline-test-'+nonce;
  return new Promise((resolve,reject)=>{
    let finished=false, state='connect',buf=Buffer.alloc(0);
    const sock=net.connect({host,port});
    const finish=(error)=>{if(finished)return;finished=true;clearTimeout(timer);sock.end();sock.destroy();if(error)reject(error);else resolve({ok:true,topic,message:msg,description:'MQTT CONNECT + SUBSCRIBE + PUBLISH + RECEIVE verified'});};
    const timer=setTimeout(()=>finish(new Error('MQTT round-trip timeout (8 seconds)')),8000);
    sock.on('connect',()=>sock.write(connectPacket('ums-'+nonce,username,password)));
    sock.on('error',e=>finish(e));
    sock.on('data',chunk=>{
      try {
        buf=Buffer.concat([buf,chunk]);let parsed;
        while((parsed=extract(buf))){buf=buf.subarray(parsed.length);const {type,body}=parsed;
          if(type===2&&state==='connect'){
            if(body.length<2||body[1]!==0){finish(new Error('EMQX rejected MQTT connection (CONNACK '+(body[1]??'?')+')'));return;}
            state='subscribe';sock.write(subscribePacket(topic));
          } else if(type===9&&state==='subscribe'){
            if(body.length<3||body[2]===0x80){finish(new Error('MQTT subscribe rejected'));return;}
            state='receive';sock.write(publishPacket(topic,msg));
          } else if(type===3&&state==='receive'){
            if(body.length<2)continue;const len=body.readUInt16BE(0);if(body.length<2+len)continue;
            const t=body.subarray(2,2+len).toString(),payload=body.subarray(2+len).toString();
            if(t===topic&&payload===msg){finish();return;}
          }
        }
      }catch(e){finish(e);}
    });
  });
}
module.exports={mqttSmoke,encodeLength,word,packet,extract};
