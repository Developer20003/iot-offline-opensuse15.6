# Node.js User Management v0.2.0 — offline project update

Updated for the successfully tested openSUSE Leap 15.6 VMware IoT lab. Existing MQTT, Kafka, Node, ThingsBoard, and PostgreSQL tests previously returned 9/9 PASS with v0.1.

## Added

- MQTT device registry (tenant slug, device code/name, state).
- Per-device one-time generated MQTT passwords, salted scrypt storage, rotation, and disabling.
- Optional EMQX 5.8 HTTP authentication/authorization POST endpoints, disabled by default.
- Exact publish/subscribe topic ACLs with denial for unmatched topics.
- Local append-only audit entries for user and device administrative actions.
- Read-only ThingsBoard tenant device listing using configured Tenant Administrator credentials.
- Browser UI tabs for Devices and Audit, plus ThingsBoard device query.
- Seven passing Node tests; additional local HTTP integration test passed.

## Preserved

- Zero npm dependencies, Node.js 22 runtime.
- User login, admin/operator/viewer roles, CSRF protection.
- MQTT 3.1.1 publish/subscribe diagnostics.
- Kafka topic list and message round-trip diagnostics.
- ThingsBoard REST and EMQX management API tests.
- Local `.env` user datastore compatibility; no migration necessary.

## Not included

- Automatic ThingsBoard provisioning or SSO.
- EMQX->Kafka->ThingsBoard telemetry bridge.
- Production database, TLS or enterprise access-control hardening.
- Microsoft VS Code RPM (private transfer only).

## Installation

Extract the ZIP to a new folder, preserve the old `.env` and data directory, validate with `node --test tests/*.test.js`, stop only the old Node server on port 3001, and start `node src/server.js`. See the 19-page manual PDF for exact commands and troubleshooting.
