---
title: "Offline IoT Development & Deployment | Complete Operator Guide"
subtitle: "openSUSE Leap 15.6 · EMQX 5.8.9 · Kafka 3.9.2 · ThingsBoard CE 4.3.1.8 · PostgreSQL 16 · Node.js 22 · VS Code"
author: "Offline release operations manual"
date: "2026-11-24"
---

# Offline IoT Development and Deployment

**Complete manual command guide — release v1 and Node.js User Management v0.2**

**System:** x86_64 openSUSE Leap 15.6. **Prepared source root:** `/opt/iot-offline-opensuse15.6`. **Working VMware lab root:** `/opt/iot-second-laptop-test`. **Publishing repository:** `https://github.com/Developer20003/iot-offline-opensuse15.6/releases`.

> **Release status (verified at documentation time):** GitHub currently has separate EMQX 5.8.9, EMQX Dashboard 1.10.5, Kafka 3.9.2, and base RPM releases. The locally assembled `leap15.6-complete-offline-v1` archive has **8 parts**; its upload to GitHub was **not yet independently verified**. On the existing VMware system, the application integration test reported **9/9 PASS**, including MQTT round-trip, Kafka produce/consume, Node login, ThingsBoard login HTTP, and PostgreSQL readiness. The latter two checks used *previously installed* services. A genuinely fresh machine installation has **not yet been proven**.

This guide is intentionally written as **real commands to type**, not as an instruction to execute a custom `.sh` file. Official vendor commands such as `kafka-server-start.sh`, `kafka-storage.sh`, and ThingsBoard's installer remain unavoidable parts of their software distributions. Each risky command has a condition explaining *when* to use it.

## 1. Contents and operating model

1. Release files, checksums, and public/private handling
2. Fresh laptop prerequisites and storage layout
3. Reassemble and extract the complete archive
4. Install and verify offline RPM prerequisites
5. Reconstruct and start Kafka 3.9.2 without ZooKeeper
6. Extract and start EMQX 5.8.9 and its Dashboard
7. PostgreSQL 16 installation and safe initialization
8. Install ThingsBoard CE 4.3.1.8 and open its UI
9. Install and use Node.js User Management v0.2
10. Use EMQX MQTT credentials, Kafka test messages, and ThingsBoard REST
11. VS Code RPM, Java, Node, and offline editing/building
12. Real historical error messages and resolutions
13. Verified integration acceptance checklist
14. Release publication, validation, and restoration
15. Future development direction (Kafka events, Elasticsearch, SSO)

### Architecture

```text
Browser → Node.js User Management (127.0.0.1:3001)
           │         ├─ own local users, roles and audit records
           │         ├─ optional EMQX HTTP authn/authz endpoint
           │         ├─ Kafka broker and topic diagnostics
           │         └─ ThingsBoard REST read-only device query
           │
IoT sensors → EMQX MQTT broker (1884 in the isolated lab)
           │                 └─ no automatic Kafka bridge yet
           └─────────────────────┐
Kafka 3.9.2 (9094)  ← standalone event platform
ThingsBoard CE 4.3.1.8 (8080) → PostgreSQL 16 (5432)

RECOMMENDED FUTURE EVENT FLOW:
Devices → EMQX → dedicated Kafka producer → Kafka topics
→ dedicated consumer/transformer → ThingsBoard telemetry API
```

**Scope boundary:** Five services passing individual health checks does **not** mean EMQX messages already flow through Kafka and ThingsBoard. Do not advertise this bridge as complete until a real telemetry value is observed in ThingsBoard.

## 2. What is in the release now?

### Confirmed release versions

| Item | Version / file | Evidence |
|---|---|---|
| Base OS | openSUSE Leap 15.6 x86_64 | preparation machine |
| EMQX | **5.8.9** `emqx589-editable-workspace.zip` | GitHub `emqx-5.8.9-offline-v1` |
| EMQX builder | `emqx589-builder-cached-linux-amd64.tar.gz` | **builder image, not a broker runtime** |
| EMQX Dashboard | **1.10.5** source package | GitHub `emqx-dashboard-v1.10.5-offline-v1` |
| Kafka | **3.9.2** `kafka_2.13-3.9.2.tgz.part-000/001` | GitHub `kafka-3.9.2-offline-v1` |
| ThingsBoard CE | **4.3.1.8**, locally built `thingsboard.rpm` | running browser and RPM build |
| PostgreSQL | **16.13** on preparation VM | authenticated `thingsboard` database |
| Java | OpenJDK 17 | built application |
| Node.js | 22.x local runtime | offline dev project |
| Node management | **v0.2.0**, downloadable project update | accompanying archive |
| Private VS Code | `vscode-x64-private-offline.tar.zst` (~392 MiB) | verified local creation, *not public* |
| Full local public archive | eight `.tar.zst.part-000`…`007` (~11.6 GiB) | complete archive script SUCCESS |

**Full repository audit:** 506,520 regular files were hashed (11.78 GiB read); the resulting `repositories.sha256` is 93 MiB. Six key application artifacts returned `OK` from `sha256sum -c`.

### Public release vs private USB

The Microsoft-distributed `code-*.x86_64.rpm` is in the **private** archive. Do **not** upload that binary to a public GitHub release. Microsoft VS Code's product terms restrict sharing/publishing the software. The open-source Code-OSS source is separately licensed. Review the licenses of the other bundled dependencies before public redistribution.

**Public transfer:** `iot-offline-opensuse15.6-leap15.6-complete-offline-v1.tar.zst.part-000` ... `part-007`, manifests, allowed project source, guides.

**Private transfer:** `vscode-x64-private-offline.tar.zst`, `SHA256SUMS.txt` for that archive, private VSIX packages (only when allowed), and optionally this guide/project ZIP. **Never transfer passwords, private keys, or `users.json` in the public bundle.**

## 3. Fresh laptop preflight (no installation yet)

Open a terminal in openSUSE Leap 15.6. These commands merely inspect the system:

```bash
uname -m
cat /etc/os-release
df -h /opt
free -h
command -v tar zstd sha256sum rpm zypper java node || true
java -version 2>&1 | head -3
ss -ltnp | grep -E ':1883|:1884|:18083|:18084|:9092|:9094|:9095|:3000|:3001|:8080|:5432' || true
```

Expected architecture is `x86_64`; retain ample free disk space. Record port ownership before launch. The **isolated VMware lab** uses 1884 / 18084 / 9094 / 9095 / 3001; the default production-style services typically use 1883 / 18083 / 9092 / 8080 / 5432. Do not let two brokers compete for a port.

> **Do not use `mvn clean`, delete `node_modules`, erase Maven/Yarn/Gradle caches, reformat Kafka storage, or run `initdb` on a nonempty PostgreSQL directory.**

## 4. Download, verify and restore the eight archive parts

On a connected device, download the eight parts and the exact release manifests from the **same release tag** (if the new release has been published), or copy them from `/opt/iot-public-release-upload` on the prepared VMware machine. Copy to a USB folder, e.g. `/run/media/$USER/USB/iot-release`. These commands run **on the second laptop** after files are present:

```bash
cd /path/to/USB/iot-release
ls -lh ./*.tar.zst.part-*
wc -l SHA256SUMS-PARTS.txt
sha256sum -c SHA256SUMS-PARTS.txt
```

All eight part checks must say `OK`. If a part is missing or marked `FAILED`, stop. Do not extract a corrupt archive.

```bash
PREFIX='iot-offline-opensuse15.6-leap15.6-complete-offline-v1.tar.zst.part-'
cat "${PREFIX}"* | sha256sum
cat SHA256-ORIGINAL.txt
```

The single concatenated SHA-256 value must match `SHA256-ORIGINAL.txt`. Then extract directly to `/opt` without creating a second full archive:

```bash
sudo mkdir -p /opt
cat "${PREFIX}"* | zstd -dc | sudo tar -xpf - -C /opt
ls -ld /opt/iot-offline-opensuse15.6/repos
```

Only use `sudo` for the extraction on the real laptop. On the working VM, choose a different empty test destination to avoid overwriting the existing repository, e.g. `/opt/iot-restore-verification`:

```bash
sudo mkdir -p /opt/iot-restore-verification
cat "${PREFIX}"* | zstd -dc | sudo tar -xpf - -C /opt/iot-restore-verification
ls /opt/iot-restore-verification/iot-offline-opensuse15.6/repos
```

**Absolute path caveat:** the locally patched ThingsBoard POM references `/opt/iot-offline-opensuse15.6/repos/04-thingsboard/gradle-distribution/gradle-7.3.3`. For development builds, ultimately restore the repository to its original `/opt/...` location.

### Verify repository contents after extraction

```bash
ROOT=/opt/iot-offline-opensuse15.6
ls -lh "$ROOT/offline-release/build-artifacts.sha256"
cd "$ROOT"
sha256sum -c offline-release/build-artifacts.sha256
```

To verify **all** repository files (large amount of disk reading):

```bash
cd /opt/iot-offline-opensuse15.6
sha256sum -c offline-release/repositories.sha256 > /tmp/iot-repository-check.log 2>&1
echo "exit code: $?"
tail -25 /tmp/iot-repository-check.log
```

This particular manifest was generated *before some project staging*. Therefore it verifies its listed files but does **not** cover every file added afterward; the archive part checksum covers the archive as a whole. Missing files must be investigated rather than silently ignored.

## 5. Offline RPM dependencies, without guessing the packages

The preparation VM had **520 RPMs** under the tree, including OpenJDK 17, Maven 3.9.9, Git, Python, `createrepo_c`, and PostgreSQL. The mere presence of RPMs does not prove that *all* dependencies required on a clean OS have been captured.

```bash
ROOT=/opt/iot-offline-opensuse15.6
find "$ROOT/repos" -type f -name '*.rpm' | wc -l
find "$ROOT/repos/01-linux-base/rpms" -maxdepth 1 -type f \
  \( -name 'java-17-openjdk*.rpm' -o -name 'maven*.rpm' \
     -o -name 'postgresql16*.rpm' -o -name 'createrepo_c*.rpm' \) | sort
rpm -q java-17-openjdk-devel maven git-core postgresql16-server || true
```

If packages are missing, test installation **without using remote repositories**. For example:

```bash
cd "$ROOT/repos/01-linux-base/rpms"
rpm -Uvh --test java-17-openjdk-headless-*.rpm java-17-openjdk-devel-*.rpm
```

If this says dependency failures, collect the exact names from the message and match additional local RPMs. Only after `--test` succeeds, install with local package files (or a verified local `zypper` repo). Avoid `--force`, `--nodeps`, and indiscriminate upgrading of every OS package.

### Missing `createrepo_c` command

Observed on VMware:

```text
createrepo_c: NOT FOUND IN PATH
```

But the offline RPM already existed:

```text
repos/01-linux-base/rpms/createrepo_c-0.16.0-150600.12.4.x86_64.rpm
repos/01-linux-base/rpms/libcreaterepo_c0-0.16.0-150600.12.4.x86_64.rpm
```

On a second laptop, inspect dependencies first:

```bash
cd /opt/iot-offline-opensuse15.6/repos/01-linux-base/rpms
rpm -qpR createrepo_c-*.rpm
rpm -Uvh --test libcreaterepo_c0-*.rpm createrepo_c-*.rpm
```

If the test passes, `sudo rpm -Uvh ...` installs these two local packages; otherwise resolve any dependencies from the prepared RPM collection.

## 6. Kafka 3.9.2: exact offline reconstruction and isolated KRaft startup

**First:** prefer an already unpacked runnable Kafka `bin/kafka-server-start.sh` with its `libs/` directory. The release has two split binary parts named `kafka_2.13-3.9.2.tgz.part-000` and `part-001`. Do not confuse the *source* or *Gradle home* with the runnable distribution.

### Reassemble from the original Kafka release files

```bash
mkdir -p /opt/iot-second-laptop-test/staging/kafka
cd /path/to/USB/kafka-3.9.2-offline-v1
sha256sum -c SHA256SUMS-parts.txt
cat kafka_2.13-3.9.2.tgz.part-000 kafka_2.13-3.9.2.tgz.part-001 \
  > /opt/iot-second-laptop-test/staging/kafka_2.13-3.9.2.tgz
```

Check the **original** archive digest (use the matching entry in `SHA256-ORIGINALS.txt`) and unpack:

```bash
cd /opt/iot-second-laptop-test/staging
grep 'kafka_2.13-3.9.2.tgz$' /path/to/USB/kafka-3.9.2-offline-v1/SHA256-ORIGINALS.txt \
  | sha256sum -c -
tar -xzf kafka_2.13-3.9.2.tgz
mkdir -p /opt/iot-second-laptop-test/runtime/kafka
cp -a kafka_2.13-3.9.2/. /opt/iot-second-laptop-test/runtime/kafka/
```

If Kafka was already staged successfully by the VMware lab, **skip** these reconstruction commands and use the existing `/opt/iot-second-laptop-test/runtime/kafka`.

### Create isolated Kafka KRaft config

```bash
LAB=/opt/iot-second-laptop-test
KAFKA="$LAB/runtime/kafka"
mkdir -p "$LAB/config" "$LAB/data/kafka" "$LAB/logs"
```

Create the properties file **only if it does not already exist**. The following command is for a new test directory:

```bash
cat > "$LAB/config/kafka.properties" <<EOF_KAFKA
process.roles=broker,controller
node.id=77
controller.quorum.voters=77@127.0.0.1:9095
controller.listener.names=CONTROLLER
listeners=PLAINTEXT://127.0.0.1:9094,CONTROLLER://127.0.0.1:9095
advertised.listeners=PLAINTEXT://127.0.0.1:9094
listener.security.protocol.map=CONTROLLER:PLAINTEXT,PLAINTEXT:PLAINTEXT
inter.broker.listener.name=PLAINTEXT
log.dirs=$LAB/data/kafka
num.partitions=1
auto.create.topics.enable=false
offsets.topic.replication.factor=1
transaction.state.log.replication.factor=1
transaction.state.log.min.isr=1
group.initial.rebalance.delay.ms=0
EOF_KAFKA
```

Do not overwrite a working config with different listeners/log dirs; inspect it with `cat` first. **Formatting is a one-time operation for an empty log directory only:**

```bash
ls -la "$LAB/data/kafka"
find "$LAB/data/kafka" -name meta.properties -print
```

Only if no metadata exists **and** the Kafka directory is completely empty:

```bash
CLUSTER_ID=$("$KAFKA/bin/kafka-storage.sh" random-uuid)
"$KAFKA/bin/kafka-storage.sh" format -t "$CLUSTER_ID" \
  -c "$LAB/config/kafka.properties"
```

**Never format an existing cluster again.** Start Kafka (first and future starts):

```bash
export KAFKA_HEAP_OPTS='-Xms256m -Xmx768m'
nohup "$KAFKA/bin/kafka-server-start.sh" "$LAB/config/kafka.properties" \
  > "$LAB/logs/kafka.log" 2>&1 &
echo "Kafka process: $!"
ss -ltnp | grep -E ':9094|:9095' || true
tail -40 "$LAB/logs/kafka.log"
```

### Kafka end-to-end produce/consume

```bash
KAFKA=/opt/iot-second-laptop-test/runtime/kafka
"$KAFKA/bin/kafka-topics.sh" --bootstrap-server 127.0.0.1:9094 \
  --create --if-not-exists --topic iot.manual.test \
  --partitions 1 --replication-factor 1
printf 'offline-kafka-check-001\n' | \
  "$KAFKA/bin/kafka-console-producer.sh" \
  --bootstrap-server 127.0.0.1:9094 --topic iot.manual.test
```

In another terminal:

```bash
KAFKA=/opt/iot-second-laptop-test/runtime/kafka
"$KAFKA/bin/kafka-console-consumer.sh" \
  --bootstrap-server 127.0.0.1:9094 --topic iot.manual.test \
  --from-beginning --max-messages 1 --timeout-ms 12000
```

Expected received line: `offline-kafka-check-001`. If a previous test record is returned first, use a newly named test topic. **Kafka has no included default web UI.** The Node.js Integrations page provides test buttons; native Kafka broker verification uses these CLI tools.

## 7. EMQX 5.8.9: compiled runtime, isolated listener, Dashboard

The GitHub release provides an editable workspace and a cached Docker **builder**. For direct Linux startup, you need the **complete compiled EMQX release directory** with `bin/emqx` and its `erts`, `lib`, `releases`, and config contents. The successful VMware 9/9 test demonstrates that *a runnable EMQX instance was present in the lab*. A builder image alone is insufficient.

Check for the compiled executable in your extracted files:

```bash
ROOT=/opt/iot-offline-opensuse15.6
find "$ROOT/repos/02-erlang-emqx" -type f -path '*/rel/emqx/bin/emqx' -print
find /opt/iot-second-laptop-test/runtime/emqx -maxdepth 2 -type f -name emqx 2>/dev/null
```

If the compiled runtime already exists at `/opt/iot-second-laptop-test/runtime/emqx`, skip copying. Otherwise, locate the containing `rel/emqx` folder and copy **all** of it, not `bin/emqx` alone:

```bash
EMQX_EXEC=$(find /opt/iot-offline-opensuse15.6/repos/02-erlang-emqx \
  -type f -path '*/rel/emqx/bin/emqx' -print -quit)
EMQX_SRC="${EMQX_EXEC%/bin/emqx}"
printf 'Source: %s\n' "$EMQX_SRC"
test -n "$EMQX_EXEC" && test -d "$EMQX_SRC/lib"
mkdir -p /opt/iot-second-laptop-test/runtime/emqx
cp -a "$EMQX_SRC/." /opt/iot-second-laptop-test/runtime/emqx/
```

**For the isolated test only**, start with distinct node name and listener ports:

```bash
LAB=/opt/iot-second-laptop-test
cd "$LAB/runtime/emqx"
export EMQX_NODE__NAME='emqx77@127.0.0.1'
export EMQX_NODE__DATA_DIR="$LAB/data/emqx"
export EMQX_LISTENERS__TCP__DEFAULT__BIND='127.0.0.1:1884'
export EMQX_LISTENERS__SSL__DEFAULT__ENABLE=false
export EMQX_LISTENERS__WS__DEFAULT__ENABLE=false
export EMQX_LISTENERS__WSS__DEFAULT__ENABLE=false
export EMQX_DASHBOARD__LISTENERS__HTTP__BIND='127.0.0.1:18084'
export EMQX_DASHBOARD__LISTENERS__HTTPS__ENABLE=false
./bin/emqx start
./bin/emqx ctl status
```

Verify Dashboard and MQTT listeners:

```bash
ss -ltnp | grep -E ':1884|:18084'
curl -I --max-time 5 http://127.0.0.1:18084/
```

Open **http://127.0.0.1:18084** in Firefox. Its login credentials are **not** the Node administrator's password and **not** the ThingsBoard system administrator credentials. For the first bootstrap, consult EMQX's installed documentation or its configured initial admin credentials; change the factory password immediately.

![Observed EMQX 5.8 Dashboard login, isolated VM port 18084](images/emqx-login.png){width=15cm}

### MQTT publish/subscribe test

The previous VMware integration test performed genuine MQTT 3.1.1 **CONNECT + SUBSCRIBE + PUBLISH + RECEIVE** on 1884. The Node project's Integration page also supports this test. A reachable TCP port by itself is not enough.

If you have a working MQTT CLI (`mosquitto_sub` and `mosquitto_pub`) installed offline, you may run:

```bash
mosquitto_sub -h 127.0.0.1 -p 1884 -t 'iot/manual/test' -v
```

In a second terminal:

```bash
mosquitto_pub -h 127.0.0.1 -p 1884 -t 'iot/manual/test' -m '{"temperature":24.5}'
```

Those CLI commands are optional and only apply when the `mosquitto-clients` RPM is actually available. The existing Node project can verify MQTT without any npm installation.

### EMQX HTTP authentication/authorization (optional new Node v0.2 feature)

**First verify the Node.js device registry and credentials.** By default `EMQX_HOOKS_ENABLED=no`, so no broker configuration changes are needed for the already passed 9/9 smoke tests. To enable later on the *isolated lab*:

1. In Node's private `.env`, set `EMQX_HOOKS_ENABLED=yes` and generate `EMQX_HOOK_KEY` with `openssl rand -hex 32`.
2. Restart Node.js after saving `.env`.
3. In EMQX Dashboard, configure an **HTTP Server authenticator**, POST to `http://127.0.0.1:3001/api/emqx/authenticate`, with header `X-EMQX-HOOK-KEY` containing the shared secret. Configure JSON body fields `username=${username}`, `clientid=${clientid}`, `password=${password}`.
4. Configure **HTTP Server authorization**, POST to `http://127.0.0.1:3001/api/emqx/authorize` with the same header and JSON body fields `username=${username}`, `clientid=${clientid}`, `topic=${topic}`, `action=${action}`.
5. Set the broker's authorization fallback / no-match behavior to **deny**. Verify that an unavailable hook server cannot fall through to a permissive authorization backend. Test with a disposable device before changing a production broker.

Successful authn returns `{ "result": "allow", "is_superuser": false }`; denied credentials return `{ "result": "deny" }`. Exact topic rules allow publish to `tenants/lab/devices/sensor-01/telemetry` and subscribe to `tenants/lab/devices/sensor-01/commands`, rejecting all other topics and wildcard subscriptions. This feature is a *local lab prototype*, not a substitute for TLS and production identity governance.

## 8. PostgreSQL 16 and ThingsBoard 4.3.1.8

On the **existing VMware machine**, both are already running and the ThingsBoard DB has **67 tables**. Do not initialize again. On a **genuinely new** openSUSE laptop, first install PostgreSQL 16 server/client from the offline RPM collection, resolve dependencies, and verify the service exists.

```bash
rpm -q postgresql16-server postgresql16
systemctl status postgresql --no-pager -l
pg_isready -h 127.0.0.1 -p 5432
```

A newly installed PostgreSQL service may require initial cluster creation by its distribution-provided mechanism; follow the package's service/packaging instructions for a *new empty* directory only. **Never run `initdb` against `/var/lib/pgsql/data` if it is nonempty or already serving databases.**

### Create a dedicated PostgreSQL role and database (new installation only)

Check for existing objects first:

```bash
runuser -u postgres -- psql -X -c \
  "SELECT rolname FROM pg_roles WHERE rolname='thingsboard';"
runuser -u postgres -- psql -X -c \
  "SELECT datname FROM pg_database WHERE datname='thingsboard';"
```

If both are absent, create them interactively without placing the password on the command line:

```bash
runuser -u postgres -- createuser --login --pwprompt thingsboard
runuser -u postgres -- createdb --owner=thingsboard --encoding=UTF8 thingsboard
```

### Real error observed: PostgreSQL `Ident authentication failed`

Observed on the first VM before fixing `pg_hba.conf`:

```text
psql: FATAL: Ident authentication failed for user "thingsboard"
```

The cause was a broad `host all all 127.0.0.1/32 ident` rule. On a new laptop, check the *actual* HBA file path and back it up before editing:

```bash
HBA=$(runuser -u postgres -- psql -X -At -c 'SHOW hba_file;')
echo "$HBA"
cp -a "$HBA" "$HBA.backup-$(date +%Y%m%d-%H%M%S)"
grep -nE '127\.0\.0\.1/32|thingsboard' "$HBA"
```

Only if the dedicated rule is missing, place it **before** broad `ident` rules:

```text
host    thingsboard    thingsboard    127.0.0.1/32    scram-sha-256
```

Use a text editor for this single line, then:

```bash
runuser -u postgres -- psql -X -c 'SELECT pg_reload_conf();'
runuser -u postgres -- psql -X -c \
  "SELECT line_number,error FROM pg_hba_file_rules WHERE error IS NOT NULL;"
psql -h 127.0.0.1 -p 5432 -U thingsboard -d thingsboard -W \
  -c 'SELECT current_user,current_database();'
```

The first VM's fixed authentication test succeeded for `thingsboard | thingsboard`.

### Install the built ThingsBoard RPM

```bash
ROOT=/opt/iot-offline-opensuse15.6
TBROOT="$ROOT/repos/04-thingsboard"
RPM="$TBROOT/source/thingsboard/application/target/thingsboard.rpm"
ls -lh "$RPM"
rpm -K "$RPM"
rpm -Uvh --test "$RPM"
```

If the test passes and it is **not installed yet**:

```bash
sudo rpm -Uvh "$RPM"
rpm -q thingsboard
```

### Configure JDBC without exposing the password on screen

After installation, edit `/usr/share/thingsboard/conf/thingsboard.conf` only if the database settings are not already present. The first VMware setup appended:

```text
export DATABASE_TS_TYPE=sql
export DATABASE_TS_LATEST_TYPE=sql
export SPRING_DATASOURCE_URL=jdbc:postgresql://127.0.0.1:5432/thingsboard
export SPRING_DATASOURCE_USERNAME=thingsboard
export SPRING_DATASOURCE_PASSWORD='a-private-password'
export TB_QUEUE_TYPE=in-memory
export JAVA_OPTS="$JAVA_OPTS -Xms512m -Xmx2048m"
```

Do **not** copy the example password. Put the real password in the protected file with shell-safe quoting, and ensure `root:thingsboard` ownership and permission mode `640`. A secure interactive method using Python 3.6+ is:

```bash
python3 - <<'PYCONFIG'
from pathlib import Path
from getpass import getpass
import shlex, os, grp
f = Path('/usr/share/thingsboard/conf/thingsboard.conf')
marker = '# THINGSBOARD OFFLINE DATABASE CONFIGURATION'
if marker in f.read_text():
    raise SystemExit('Database configuration already exists. Inspect before changing.')
pw = getpass('PostgreSQL thingsboard password: ')
if not pw: raise SystemExit('Password cannot be empty')
with f.open('a') as out:
    out.write('\n' + marker + '\n')
    out.write('export DATABASE_TS_TYPE=sql\n')
    out.write('export DATABASE_TS_LATEST_TYPE=sql\n')
    out.write('export SPRING_DATASOURCE_URL=jdbc:postgresql://127.0.0.1:5432/thingsboard\n')
    out.write('export SPRING_DATASOURCE_USERNAME=thingsboard\n')
    out.write('export SPRING_DATASOURCE_PASSWORD=' + shlex.quote(pw) + '\n')
    out.write('export TB_QUEUE_TYPE=in-memory\n')
    out.write('export JAVA_OPTS="$JAVA_OPTS -Xms512m -Xmx2048m"\n')
os.chown(str(f), 0, grp.getgrnam('thingsboard').gr_gid)
os.chmod(str(f), 0o640)
print('Protected JDBC configuration saved')
PYCONFIG
```

### Initialize ThingsBoard database *once*

Check the table count before deciding to run the installer:

```bash
runuser -u postgres -- psql -X -d thingsboard \
  -c "SELECT COUNT(*) FROM pg_tables WHERE schemaname='public';"
```

On the original machine the count was **0** before installation, then **67** afterward. **If tables are present, do not rerun the installer.** If new and empty:

```bash
bash /usr/share/thingsboard/bin/install/install.sh
```

Real successful output on the original VM:

```text
Installing DataBase schema for entities...
Installing DataBase schema for timeseries...
Loading system widgets
Loading system SCADA symbols
Installation finished successfully!
ThingsBoard installed successfully!
```

A harmless JDK warning also appeared:

```text
OpenJDK 64-Bit Server VM warning: Option UseBiasedLocking was deprecated in version 15.0
```

### Start and verify ThingsBoard

```bash
sudo systemctl daemon-reload
sudo systemctl start thingsboard
systemctl status thingsboard --no-pager -l
ss -ltnp | grep ':8080' || true
curl --max-time 10 -sS -o /dev/null -w '%{http_code}\n' http://127.0.0.1:8080/login
journalctl -u thingsboard -n 60 --no-pager
```

Open **http://localhost:8080**. In the original VM, using the bare username `admin` caused:

```text
Invalid email format.
```

ThingsBoard's default **System Administrator email** on a new installation is `sysadmin@thingsboard.org` (initial password `sysadmin` unless already changed). Immediately replace default credentials after first sign-in.

![Observed ThingsBoard CE 4.3.1.8 login on the VMware machine](images/thingsboard-login.png){width=15cm}

![Observed ThingsBoard System Administrator home after sign-in](images/thingsboard-admin.png){width=15cm}

The red/green version banner about newer ThingsBoard 4.4 releases does **not** mean you should upgrade this offline 4.3.1.8 installation. Avoid a version change until the offline rebuild, database migrations, and backups have been planned.

## 9. Node.js User Management v0.2.0 (updated project)

This release includes a **zero npm dependency** Node 22 web UI. It is a standalone management application, **not a telemetry bridge**. Version 0.2 adds:

- Local user creation, roles (`admin`, `operator`, `viewer`), disable, password change through API.
- Local MQTT device registration, activation, one-time generated password, and password rotation.
- Optional EMQX v5 HTTP authentication and topic authorization, **disabled by default**.
- Local append-only JSONL audit entries for user/device management.
- Read-only ThingsBoard Tenant Administrator device listing (credential required).
- Existing MQTT, Kafka, ThingsBoard, and EMQX API diagnostics.

### Preserve existing administrator records during upgrade

**Do not delete or overwrite** `users.json`, `devices.json`, the existing `.env`, or the lab's private administrator password. The old user store is compatible. The new device registry is created alongside it only when needed.

Extract `offline-iot-user-management-v0.2.0.zip` to a separate folder:

```bash
LAB=/opt/iot-second-laptop-test
mkdir -p "$LAB/updated-app"
unzip -q /path/to/offline-iot-user-management-v0.2.0.zip -d "$LAB/updated-app"
APP="$LAB/updated-app/offline-iot-user-management"
ls "$APP/src/server.js" "$APP/src/devices.js" "$APP/public/index.html"
```

Copy the **existing private configuration** into the upgraded project only on the same trusted machine:

```bash
cp -a "$LAB/user-management/.env" "$APP/.env"
chmod 600 "$APP/.env"
```

Keep the `USER_DATA_DIR` value the same to reuse users and audit data. The isolated lab uses:

```text
HOST=127.0.0.1
PORT=3001
USER_DATA_DIR=/opt/iot-second-laptop-test/data/users
EMQX_HOST=127.0.0.1
EMQX_PORT=1884
EMQX_DASHBOARD_URL=http://127.0.0.1:18084
KAFKA_HOST=127.0.0.1
KAFKA_PORT=9094
TB_URL=http://127.0.0.1:8080
EMQX_HOOKS_ENABLED=no
```

If the old Node server still owns port 3001, first identify its PID and stop **only that process**, not Kafka, EMQX or ThingsBoard:

```bash
ss -ltnp | grep ':3001'
ps -eo pid,args | grep '[s]rc/server.js'
```

After confirming the PID belongs to the old lab `src/server.js`, stop it with `kill <PID>`; **do not blindly kill all `node` processes**. Then start the updated app:

```bash
LAB=/opt/iot-second-laptop-test
APP="$LAB/updated-app/offline-iot-user-management"
"$LAB/runtime/node" --version
"$LAB/runtime/node" --test "$APP"/tests/*.test.js
"$LAB/runtime/node" "$APP/src/server.js"
```

Use a second terminal for tests:

```bash
curl -sS http://127.0.0.1:3001/api/health
ss -ltnp | grep ':3001'
```

Open **http://127.0.0.1:3001**. On the *original* VMware lab, the user-management login was `admin@local.test`, and its generated password was saved at:

```text
/opt/iot-second-laptop-test/private/first-admin-password.txt
```

The browser once displayed **`Invalid email or password`** even though the programmatic login test passed; that meant the submitted browser password did not match the locally initialized user. **Changing `ADMIN_PASSWORD` in `.env` after initial bootstrap does not reset an existing user's password.** Use the original generated private password or an authenticated admin password-change operation. Never publish the password file.

![Observed Node.js v0.1 login with a failed manual attempt; later command-line login passed](images/node-login-error.png){width=15cm}

### Register a device through the updated UI

Sign in as a local admin → **Devices** → **Register device** → tenant `lab`, code `sensor-01`, name `Air Sensor`. The UI reveals a generated MQTT password **once**. Save it in a secure personal location; the app stores only a salted password hash.

The resulting authorization scope is:

```text
MQTT username / clientid: sensor-01
Allowed publish:  tenants/lab/devices/sensor-01/telemetry
Allowed subscribe: tenants/lab/devices/sensor-01/commands
All other topics: deny when the HTTP hooks are enabled and EMQX is fail-closed
```

The account is **local to this Node app**. It does not automatically create a ThingsBoard device or write a Kafka record. The optional ThingsBoard device-list query is read-only and requires a **Tenant Administrator** login; the existing System Administrator session does not automatically have access to `/api/tenant/devices`.

### Use the Integrations page

From the web UI, run each available test: **MQTT round-trip**, **Kafka admin**, **Kafka produce/consume**, **ThingsBoard REST login**, **EMQX Management API**, and **List ThingsBoard devices** (if configured). Green results are specific to the test performed. Tests requiring unconfigured credentials correctly report a configuration issue rather than fake success.

## 10. Offline VS Code RPM installation and development

The private archive was already created successfully on the first VM:

```text
/opt/iot-private-transfer/vscode-x64-private-offline.tar.zst
Size: 392 MiB
/opt/iot-private-transfer/SHA256SUMS.txt
```

On the second laptop, copy these two files via private USB and verify:

```bash
cd /path/to/private-USB
sha256sum -c SHA256SUMS.txt
sudo mkdir -p /opt/iot-private-installers
zstd -dc vscode-x64-private-offline.tar.zst \
  | sudo tar -xpf - -C /opt/iot-private-installers
find /opt/iot-private-installers -type f -name 'code-*.rpm' -print
```

The archive contains a `vscode/rpms` directory. Check the RPM details and its required packages *before installation*:

```bash
cd /opt/iot-private-installers/vscode/rpms
ls -lh code-*.rpm
rpm -K code-*.rpm
rpm -qpR code-*.rpm
rpm -Uvh --test code-*.rpm
```

`rpm -K` may show `digests OK` but signature verification can depend on the installed Microsoft signing key; do not silently ignore a failed signature if authenticity cannot be verified. If dependencies are missing, find and install them from verified local openSUSE RPMs. Install the RPM only when dependency checks pass:

```bash
sudo rpm -Uvh code-*.rpm
code --version
```

For offline extensions, save `.vsix` packages and their relevant licenses privately before disconnecting:

```bash
code --install-extension /path/to/extension.vsix
code --list-extensions --show-versions
```

Open the updated Node project and start debugging:

```bash
cd /opt/iot-second-laptop-test/updated-app/offline-iot-user-management
code .
```

Use the built-in terminal (`Ctrl+\``), review `src/server.js`, `src/devices.js`, `public/index.html`, `public/app.js`, and run the local Node 22 runtime. **The app has zero npm dependencies**, so it does not require `npm install` or Internet access.

For ThingsBoard Java development, keep the original Maven repository and patched Gradle path; check before building:

```bash
ROOT=/opt/iot-offline-opensuse15.6
TBROOT="$ROOT/repos/04-thingsboard"
TBSRC="$TBROOT/source/thingsboard"
java -version
mvn -version
ls "$TBROOT/settings-central-compatible.xml" "$TBROOT/maven-repo"
grep -n -E 'gradleInstallationDir|gradleUserHomeDir' "$TBSRC/pom.xml"
git -C "$TBSRC" status --short
```

The original source showed `M pom.xml` and `?? pom.xml.before-local-gradle`; **these are intentional local build configuration artifacts**. Copy them with the source. Test non-destructively (`mvn -o ...` with the correct project-specific goals); **do not start by running `mvn clean`**. The previous Java build and Angular production bundle were already successfully generated.

## 11. Exact historical errors: symptom, cause, corrective action

| Observed message / symptom | Meaning and action |
|---|---|
| `FATAL: Ident authentication failed for user "thingsboard"` | PostgreSQL host rule used `ident`; add a specific `scram-sha-256` rule above the broad rule, reload, retest `psql -W`. |
| `Database configuration already exists. Inspect before changing.` | Safeguard prevented appending a duplicate password/config block. **Do not rerun** the config writer. |
| `systemctl is-active thingsboard` → `inactive` | The application was installed but not yet started. Check journal/config; `systemctl start thingsboard` after DB initialization. |
| `OpenJDK ... Option UseBiasedLocking was deprecated` | Warning seen during successful installation; not a database installation failure. |
| `Invalid email format.` on ThingsBoard login | Bare `admin` is not an email address; use the configured System Administrator email. |
| `Invalid email or password` on Node UI | Browser credentials did not match local stored user hash; look up the privately generated first-admin password. |
| EMQX Dashboard shows `Username is required` / `Password is required` | Form has empty fields, not evidence of a broken EMQX broker. |
| `createrepo_c: NOT FOUND IN PATH` | RPM is present offline but tool not installed; test and install local `createrepo_c` and library RPMs. |
| Full SHA-256 manifest stopped with `^C` | Incomplete earlier attempt; later successful run hashed 506,520 files. Do not trust a partial manifest. |
| `Creating streamed release parts...` prints nothing for a long period | TAR must read >500,000 files and zstd compress ~19 GiB source. Monitor `ps`, `du`, and disk usage in **another terminal**. |
| `SUCCESS: 8 split archive part(s)` | Local archive completed. **Not proof that GitHub upload completed.** |
| `ThingsBoard 4.4.0.2 is available` in UI | A version announcement, not an instruction to change the tested 4.3.1.8 release. |

### Troubleshooting commands to capture evidence

```bash
# All relevant TCP listeners
ss -ltnp | grep -E ':1884|:18084|:9094|:9095|:3001|:8080|:5432' || true

# Kafka broker log (isolated environment)
tail -100 /opt/iot-second-laptop-test/logs/kafka.log

# ThingsBoard service logs
journalctl -u thingsboard -n 100 --no-pager

# PostgreSQL listener and credentials test
pg_isready -h 127.0.0.1 -p 5432

# Node application HTTP health
curl -sS http://127.0.0.1:3001/api/health

# EMQX Dashboard page status
curl --max-time 5 -I http://127.0.0.1:18084/
```

**Do not paste private `.env`, SQL passwords, MQTT secrets or API tokens into support messages.** Redact personal data in logs.

## 12. Acceptance checklist: what has actually been proven

The original VMware lab reported these **nine actual results**:

```text
PASS: EMQX MQTT TCP listener on 1884
PASS: EMQX Dashboard HTTP on 18084
PASS: EMQX MQTT CONNECT + SUBSCRIBE + PUBLISH + RECEIVE
PASS: Kafka broker TCP 9094
PASS: Kafka create/produce/consume/delete isolated topic
PASS: Node UI HTTP 3001
PASS: Node administrator login + status API
PASS: Existing ThingsBoard web UI 8080
PASS: Existing PostgreSQL local readiness
=== RESULT: 9 / 9 checks passed ===
```

The new v0.2 project was separately tested in the document preparation environment: **7 Node unit tests passed**, plus local HTTP integration of device registration, EMQX auth/authz hooks, device listing and audit. This does **not** mean the new project has yet been retested against the actual VMware EMQX/Kafka brokers.

**Still required for a true second-laptop signoff:** fresh offline OS dependency installation, isolated ThingsBoard/PostgreSQL creation, VS Code RPM installation and debug, updated Node UI on VMware, and actual EMQX → Kafka → ThingsBoard telemetry flow.

## 13. Public GitHub Release vs private VS Code/update transfer

The completed local archive files are located at:

```text
/opt/iot-public-release-upload/
  iot-offline-opensuse15.6-leap15.6-complete-offline-v1.tar.zst.part-000
  ... part-007
  SHA256SUMS-PARTS.txt
  SHA256-ORIGINAL.txt
  RELEASE-NOTES.md
```

The new project/guide **were created after that eight-part archive**. Therefore, **do not claim they are included in those eight archive parts**. Either publish a separate project/source-and-guide release, or include them when producing a new versioned main archive. Do not rerun the completed 11.6 GiB compression under the same release tag unless deliberately making a new version.

### Recommended: add the new project/guide alongside private VS Code without recompressing 392 MiB

```bash
mkdir -p /opt/iot-private-transfer/updates
cp /path/to/offline-iot-user-management-v0.2.0.zip \
  /opt/iot-private-transfer/updates/
cp /path/to/Offline_IoT_Complete_Operator_Guide.pdf \
  /opt/iot-private-transfer/updates/
cp /path/to/Offline_IoT_Complete_Operator_Guide.docx \
  /opt/iot-private-transfer/updates/
cp /path/to/README.md /opt/iot-private-transfer/updates/
cd /opt/iot-private-transfer/updates
sha256sum * > SHA256SUMS-UPDATES.txt
```

Copy both `vscode-x64-private-offline.tar.zst` and the `updates/` folder to the private USB. This avoids re-archiving the existing VS Code RPM and avoids publishing Microsoft's binary.

### Public GitHub upload of the eight archive parts (only after license/secrets audit)

```bash
cd /opt/iot-public-release-upload
sha256sum -c SHA256SUMS-PARTS.txt
cat ./*.tar.zst.part-* | sha256sum
cat SHA256-ORIGINAL.txt
```

On the connected publishing machine, after installing/authenticating GitHub CLI and confirming write access:

```bash
gh auth status
gh release view leap15.6-complete-offline-v1 \
  --repo Developer20003/iot-offline-opensuse15.6 || true
```

If the release does not exist, create a **draft** with release notes; upload only audited assets. `gh release upload` can upload specific part files or a glob; avoid the private VS Code directory. After upload:

```bash
gh release view leap15.6-complete-offline-v1 \
  --repo Developer20003/iot-offline-opensuse15.6 \
  --json name,isDraft,assets \
  --jq '{name: .name, draft: .isDraft, assets: [.assets[].name]}'
```

A public package is not the same as a fully tested offline install. Before changing a draft release to public, review third-party licenses, source secrets, and the asset list.

## 14. Future development roadmap

**Phase A – current tested lab:** Kafka and EMQX working separately, ThingsBoard running, Node prototype with users and device registry. Preserve the 9/9 test baseline.

**Phase B – lifecycle integration:** Node application owns organization membership and authorization; ThingsBoard has appropriate tenant/customer accounts provisioned through its REST API, with idempotency and audit. EMQX uses secure per-device credentials and topic ACLs. Kafka carries user/device lifecycle events using a dedicated producer, durable outbox, event IDs and retries.

**Phase C – telemetry data path:** explicit EMQX → Kafka producer → Kafka consumer → ThingsBoard HTTP/MQTT API. Map external device IDs to ThingsBoard device IDs/token storage securely, implement dead-letter topics, backpressure, and delivery acknowledgment. Prove a sensor value from MQTT appears on a ThingsBoard tenant dashboard.

**Phase D – searchable history / Elasticsearch:** Kafka consumer sends selected telemetry and audit events to Elasticsearch; use index templates, ILM/retention, structured mappings, and least-privilege service credentials. **Do not replace ThingsBoard's PostgreSQL database with Elasticsearch.** Validate exact Elasticsearch version/OS compatibility, package all runtime dependencies offline, and estimate disk growth before deployment.

**Phase E – production hardening:** HTTPS reverse proxy, centralized identity/SSO, PostgreSQL for the Node application, RBAC by organization, authenticated Kafka SASL/ACL, TLS MQTT listeners, monitoring, backups, restore drills, and a reproducible clean-VM installation test.

## 15. External source references

- [Developer20003 GitHub Releases](https://github.com/Developer20003/iot-offline-opensuse15.6/releases) — actual currently published EMQX/Kafka/base RPM assets.
- [Apache Kafka 3.9 Quick Start](https://kafka.apache.org/39/getting-started/quickstart/) — KRaft storage format and broker startup.
- [EMQX HTTP authentication](https://docs.emqx.com/en/emqx/latest/guides/access-control/authn/http.html) — expected JSON `result` and `is_superuser` fields.
- [EMQX HTTP authorization](https://docs.emqx.com/en/emqx/latest/guides/access-control/authz/http.html) — request fields and response semantics; ensure fallback is deny.
- [Microsoft Visual Studio Code License](https://code.visualstudio.com/License/) — the official binary's redistribution restriction.

*End of guide. Do not execute fresh-init commands on existing active PostgreSQL or Kafka data. Always verify checksums and isolate private secrets from public release artifacts.*
