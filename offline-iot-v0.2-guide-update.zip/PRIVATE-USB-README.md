# Updated Node.js User Management and 19-page manual — private offline transfer

## Files in this update ZIP

- `offline-iot-user-management-v0.2.0.zip` — updated, dependency-free Node.js project, browser UI, EMQX HTTP hooks, local device registry, audit log and tests.
- `Offline_IoT_Complete_Operator_Guide.pdf` — illustrated detailed terminal-command operator guide.
- `Offline_IoT_Complete_Operator_Guide.docx` — editable Word copy.
- `guide/README.md` and `guide/images/` — editable Markdown guide and referenced screenshots.
- `SHA256SUMS.txt` — integrity manifest of these update files.

**This ZIP does not include Microsoft VS Code RPM binaries**. You already built the private VS Code installer as:
`/opt/iot-private-transfer/vscode-x64-private-offline.tar.zst` (~392 MiB).
Keep the private VS Code installer and the new update ZIP **next to each other** on your own USB drive.

## On VMware / first laptop: arrange files beside the VS Code archive

```bash
mkdir -p /opt/iot-private-transfer/updates
cp /path/to/offline-iot-v0.2-guide-update.zip /opt/iot-private-transfer/updates/
cd /opt/iot-private-transfer/updates
sha256sum offline-iot-v0.2-guide-update.zip > SHA256SUMS-UPDATE-ZIP.txt
ls -lh /opt/iot-private-transfer/vscode-x64-private-offline.tar.zst \
       /opt/iot-private-transfer/updates/offline-iot-v0.2-guide-update.zip
```

Copy the parent `/opt/iot-private-transfer/` directory to your private USB. The existing VS Code private archive checksum is at `/opt/iot-private-transfer/SHA256SUMS.txt`.

## On the second laptop: unpack the updates

```bash
cd /path/to/private-USB/updates
sha256sum -c SHA256SUMS-UPDATE-ZIP.txt
mkdir -p "$HOME/iot-guide-and-project-v0.2"
unzip -q offline-iot-v0.2-guide-update.zip -d "$HOME/iot-guide-and-project-v0.2"
cd "$HOME/iot-guide-and-project-v0.2"
sha256sum -c SHA256SUMS.txt
```

Open the PDF, follow the **manual commands**, then install VS Code from the separate private archive. For upgrading the running lab Node app, keep the existing `.env` and `USER_DATA_DIR` and verify/stop only the old Node process before starting the new one.

## Public publication

You may independently upload the Node project source and guide to GitHub **after review**, but **do not upload the Microsoft `code-*.rpm` or private VSIX software** to your public repository. Check licensing for any included third-party material and review all files for secrets.
